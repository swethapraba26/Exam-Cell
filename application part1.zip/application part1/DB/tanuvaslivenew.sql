﻿-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.6.20 - MySQL Community Server (GPL)
-- Server OS:                    Win32
-- HeidiSQL Version:             9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table tanuvaslivenew.attendance
DROP TABLE IF EXISTS `attendance`;
CREATE TABLE IF NOT EXISTS `attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attendance_date` date DEFAULT NULL,
  `attendance_period` int(11) DEFAULT NULL,
  `attendance_status` enum('P','A') DEFAULT 'P',
  `degree_id` int(11) DEFAULT NULL,
  `semester_id` int(11) DEFAULT NULL,
  `batch_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `login_user_id` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `updated_on` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1667 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.attendance: ~1,405 rows (approximately)
/*!40000 ALTER TABLE `attendance` DISABLE KEYS */;
INSERT INTO `attendance` (`id`, `attendance_date`, `attendance_period`, `attendance_status`, `degree_id`, `semester_id`, `batch_id`, `course_id`, `student_id`, `login_user_id`, `created_on`, `updated_on`) VALUES
	(262, '2018-12-31', 1, 'P', 1, 1, 1, 1, 120, 572, '2019-01-23 12:29:46', '2019-01-23 12:29:46'),
	(263, '2018-12-31', 2, 'P', 1, 1, 1, 1, 120, 572, '2019-01-23 12:29:46', '2019-01-23 12:29:46'),
	(264, '2018-12-31', 1, 'A', 1, 1, 1, 1, 122, 572, '2019-01-23 12:29:46', '2019-01-23 12:29:46'),
	(265, '2018-12-31', 2, 'P', 1, 1, 1, 1, 122, 572, '2019-01-23 12:29:46', '2019-01-23 12:29:46'),
	(266, '2018-12-31', 1, 'P', 1, 1, 1, 1, 127, 572, '2019-01-23 12:29:46', '2019-01-23 12:29:46'),
	(267, '2018-12-31', 2, 'A', 1, 1, 1, 1, 127, 572, '2019-01-23 12:29:47', '2019-01-23 12:29:47'),
	(268, '2018-12-31', 1, 'A', 1, 1, 1, 1, 131, 572, '2019-01-23 12:29:47', '2019-01-23 12:29:47'),
	(269, '2018-12-31', 2, 'P', 1, 1, 1, 1, 131, 572, '2019-01-23 12:29:47', '2019-01-23 12:29:47'),
	(270, '2018-12-31', 1, 'P', 1, 1, 1, 1, 153, 572, '2019-01-23 12:29:47', '2019-01-23 12:29:47'),
	(271, '2018-12-31', 2, 'A', 1, 1, 1, 1, 153, 572, '2019-01-23 12:29:47', '2019-01-23 12:29:47'),
	(272, '2018-12-31', 1, 'P', 1, 1, 1, 1, 156, 572, '2019-01-23 12:29:47', '2019-01-23 12:29:47');
	
/*!40000 ALTER TABLE `attendance` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.attendance_course_assigned_teacher
DROP TABLE IF EXISTS `attendance_course_assigned_teacher`;
CREATE TABLE IF NOT EXISTS `attendance_course_assigned_teacher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campus_id` int(11) NOT NULL,
  `program_id` int(11) NOT NULL,
  `degree_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `semester_id` int(11) NOT NULL,
  `discipline_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.attendance_course_assigned_teacher: 8 rows
/*!40000 ALTER TABLE `attendance_course_assigned_teacher` DISABLE KEYS */;
INSERT INTO `attendance_course_assigned_teacher` (`id`, `campus_id`, `program_id`, `degree_id`, `batch_id`, `semester_id`, `discipline_id`, `course_id`, `teacher_id`, `created_on`) VALUES
	(10, 1, 1, 1, 1, 1, 1, 1, 572, '2019-01-23 11:42:28'),
	(11, 1, 1, 1, 1, 1, 1, 2, 572, '2019-01-23 11:42:28'),
	(3, 1, 1, 1, 1, 1, 1, 3, 572, '2019-01-22 19:50:20'),
	(12, 1, 1, 1, 1, 1, 1, 4, 572, '2019-01-23 11:42:28'),
	(13, 1, 1, 1, 1, 1, 1, 5, 572, '2019-01-23 11:42:28'),
	(14, 1, 1, 1, 1, 1, 1, 6, 572, '2019-01-23 11:42:28'),
	(15, 1, 1, 1, 1, 1, 1, 32, 572, '2019-01-23 11:42:28'),
	(16, 1, 1, 1, 1, 1, 1, 1, 572, '2019-02-06 15:55:42');
/*!40000 ALTER TABLE `attendance_course_assigned_teacher` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.attendance_time_table
DROP TABLE IF EXISTS `attendance_time_table`;
CREATE TABLE IF NOT EXISTS `attendance_time_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) DEFAULT NULL,
  `degree_id` int(11) DEFAULT NULL,
  `semester_id` int(11) DEFAULT NULL,
  `day` int(11) DEFAULT NULL,
  `from` int(11) DEFAULT NULL,
  `to` int(11) DEFAULT NULL,
  `created_on` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=394 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.attendance_time_table: ~48 rows (approximately)
/*!40000 ALTER TABLE `attendance_time_table` DISABLE KEYS */;
INSERT INTO `attendance_time_table` (`id`, `course_id`, `degree_id`, `semester_id`, `day`, `from`, `to`, `created_on`, `created_by`) VALUES
	(346, 32, 1, 1, 0, 9, 10, '2019-02-11 13:05:25', 1),
	(347, 32, 1, 1, 1, 9, 10, '2019-02-11 13:05:25', 1),
	(348, 32, 1, 1, 2, 9, 10, '2019-02-11 13:05:25', 1),
	(349, 32, 1, 1, 3, 9, 10, '2019-02-11 13:05:25', 1),
	(350, 32, 1, 1, 4, 9, 10, '2019-02-11 13:05:25', 1),
	(351, 32, 1, 1, 5, 9, 10, '2019-02-11 13:05:25', 1),
	(352, 1, 1, 1, 5, 6, 7, '2019-02-11 13:05:25', 1),
	(353, 1, 1, 1, 5, 7, 8, '2019-02-11 13:05:25', 1),
	(354, 1, 1, 1, 5, 8, 9, '2019-02-11 13:05:25', 1),
	(355, 2, 1, 1, 0, 3, 4, '2019-02-11 13:05:25', 1),
	(356, 2, 1, 1, 0, 4, 6, '2019-02-11 13:05:25', 1);
/*!40000 ALTER TABLE `attendance_time_table` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.batches
DROP TABLE IF EXISTS `batches`;
CREATE TABLE IF NOT EXISTS `batches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `syllabus_id` int(11) NOT NULL,
  `batch_start_year` varchar(20) NOT NULL,
  `batch_name` varchar(50) NOT NULL,
  `status` bigint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.batches: ~2 rows (approximately)
/*!40000 ALTER TABLE `batches` DISABLE KEYS */;
INSERT INTO `batches` (`id`, `syllabus_id`, `batch_start_year`, `batch_name`, `status`) VALUES
	(1, 1, '2017', '2017-2018', 1),
	(2, 2, '2018', '2018-2019', 1);
/*!40000 ALTER TABLE `batches` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.campuses
DROP TABLE IF EXISTS `campuses`;
CREATE TABLE IF NOT EXISTS `campuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campus_code` varchar(100) NOT NULL,
  `campus_name` varchar(100) DEFAULT NULL,
  `campus_short_name` varchar(100) DEFAULT NULL,
  `address1` text,
  `address2` text,
  `address3` text,
  `address4` text,
  `landline_number` bigint(20) DEFAULT NULL,
  `mobile_number` varchar(50) DEFAULT NULL,
  `fax_number` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `login_id` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `confirm_password` varchar(100) DEFAULT NULL,
  `dean_name` varchar(100) DEFAULT NULL,
  `dean_phone_number` varchar(100) DEFAULT NULL,
  `dean_email` varchar(100) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.campuses: ~6 rows (approximately)
/*!40000 ALTER TABLE `campuses` DISABLE KEYS */;
INSERT INTO `campuses` (`id`, `campus_code`, `campus_name`, `campus_short_name`, `address1`, `address2`, `address3`, `address4`, `landline_number`, `mobile_number`, `fax_number`, `email`, `login_id`, `password`, `confirm_password`, `dean_name`, `dean_phone_number`, `dean_email`, `created_on`, `updated_on`, `status`) VALUES
	(1, 'MVC, Chennai', 'Madras Veterinary College, Chennai', 'MVC', 'Chennai', 'Chennai', 'Chennai', 'Chennai', 8787878787, '8787878787', '8787878787', 'mvc@gmail.com', 'mvc', 'mvc', NULL, 'MVC', '8787878787', 'MVC', '2018-08-06 13:10:21', '2018-08-07 13:10:21', 1),
	(2, 'BVN, Namakkal', 'Veterinary  College and Research Institute, Namakkal', 'VCRI-NKL', 'Namakkal', 'Namakkal', 'Namakkal', 'Namakkal', 7897897897, '7897897897', '7878784787', 'namakkal@gmail.com', 'namakkal', 'namakkal', NULL, 'namakkal', '9635504472', 'namakkal@gmail.com', '2018-08-06 13:14:52', '2018-08-07 13:10:38', 1),
	(3, 'BVO, Orathanadu', 'Veterinary  College and Research Institute, Orathanadu', 'VCRI-OND', 'Orathanadu', 'Orathanadu', 'Orathanadu', 'Orathanadu', 9635504472, '9635504472', '9635504472', 'orathanadu@gmail.com', 'orathanadu', 'orathanadu', NULL, 'Orathanadu', '9635504472', 'orathanadu@gmail.com', '2018-08-06 13:44:58', '2018-08-07 13:10:56', 1),
	(4, 'BVT, Tirunelveli', 'Veterinary  College and Research Institute, Tirunelveli', 'VCRI-TVL', 'Tirunelveli', 'Tirunelveli', 'Tirunelveli', 'Tirunelveli', 9635504472, '9635504472', '9636504472', 'tirunelveli@gmail.com', 'tirunelveli', 'tirunelveli', NULL, 'tirunelveli', '9635504472', 'tirunelveli@gmail.com', '2018-08-06 13:49:46', '2018-08-07 13:11:06', 1),
	(5, 'CPPM, Hosur', 'College  of Poultry Production Management, Hosur', 'College  of Poultry Production Management', '', '', '', '', 123456, '9635504472', '', '', 'nazim', '123456', NULL, 'Demo Nazim', '9635504472', 'dean@democppm@gmail.com', '2018-08-21 15:30:21', '2018-08-22 12:33:39', 1),
	(6, 'CFDT, Koduvalli', 'College  of  Food and Diary Technology, Koduvalli', 'College  of  Food and Diary Technology', '', '', '', '', 123456, '', '', '', 'deft', '123456', NULL, 'Demo Cfdt', '9635504472', 'dean.cdft@gmail.com', '2018-08-21 15:33:05', '2018-08-22 13:11:00', 1);
/*!40000 ALTER TABLE `campuses` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.campus_map_degree_and_programs
DROP TABLE IF EXISTS `campus_map_degree_and_programs`;
CREATE TABLE IF NOT EXISTS `campus_map_degree_and_programs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campus_id` int(11) NOT NULL,
  `degree_id` int(11) NOT NULL,
  `program_id` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.campus_map_degree_and_programs: 14 rows
/*!40000 ALTER TABLE `campus_map_degree_and_programs` DISABLE KEYS */;
INSERT INTO `campus_map_degree_and_programs` (`id`, `campus_id`, `degree_id`, `program_id`, `created_on`, `status`) VALUES
	(1, 1, 1, 1, '2018-08-06 13:50:42', 1),
	(18, 6, 4, 1, '2018-11-26 21:17:13', 1),
	(17, 6, 3, 2, '2018-11-26 21:17:13', 1),
	(16, 6, 3, 1, '2018-11-26 21:17:13', 1),
	(20, 2, 1, 1, '2018-08-06 13:50:42', 1),
	(9, 1, 6, 2, '2018-11-26 21:17:13', 1),
	(10, 5, 2, 1, '2018-11-26 21:17:13', 1),
	(11, 5, 2, 2, '2018-11-26 21:17:13', 1),
	(23, 3, 6, 2, '2018-11-26 21:17:13', 1),
	(22, 3, 1, 1, '2018-08-06 13:50:42', 1),
	(21, 2, 6, 2, '2018-11-26 21:17:13', 1),
	(19, 6, 4, 2, '2018-11-26 21:17:13', 1),
	(24, 4, 1, 1, '2018-08-06 13:50:42', 1),
	(25, 4, 6, 2, '2018-11-26 21:17:13', 1);
/*!40000 ALTER TABLE `campus_map_degree_and_programs` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.caste
DROP TABLE IF EXISTS `caste`;
CREATE TABLE IF NOT EXISTS `caste` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `community_id` int(11) NOT NULL DEFAULT '0',
  `name` tinytext,
  `status` enum('Y','N') DEFAULT 'Y',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=224 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.caste: ~135 rows (approximately)
/*!40000 ALTER TABLE `caste` DISABLE KEYS */;
INSERT INTO `caste` (`id`, `community_id`, `name`, `status`) VALUES
	(2, 1, 'Adi Karnataka', 'Y'),
	(3, 1, 'Ajila', 'Y'),
	(4, 1, 'Ayyanavar', 'Y'),
	(5, 1, 'Baira', 'Y'),
	(6, 1, 'Bakuda', 'Y'),
	(7, 1, 'Bandi', 'Y'),
	(8, 1, 'Bellara', 'Y'),
	(9, 1, 'Bharatar', 'Y'),
	(10, 1, 'Chalavadi', 'Y');
/*!40000 ALTER TABLE `caste` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.certificate_fee
DROP TABLE IF EXISTS `certificate_fee`;
CREATE TABLE IF NOT EXISTS `certificate_fee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `fee_amount` int(11) DEFAULT NULL,
  `revaluation` int(11) DEFAULT NULL,
  `exam_fee` int(11) DEFAULT NULL,
  `duplicate_amount` int(11) DEFAULT NULL,
  `status` enum('Y','N') DEFAULT 'Y',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.certificate_fee: ~10 rows (approximately)
/*!40000 ALTER TABLE `certificate_fee` DISABLE KEYS */;
INSERT INTO `certificate_fee` (`id`, `name`, `fee_amount`, `revaluation`, `exam_fee`, `duplicate_amount`, `status`) VALUES
	(1, 'FIRST YEAR ANNUAL BOARD EXAMINATIONS', 50, 500, 100, 50, 'Y'),
	(2, 'Second Professional Year', 50, 500, 100, 50, 'Y'),
	(3, 'Third Professional Year', 50, 500, 100, 50, 'Y'),
	(4, 'Fourth Professional Year', 50, 500, 100, 50, 'Y'),
	(5, 'All Professional Year', 200, NULL, NULL, 200, 'Y'),
	(6, 'Consolidate Marksheet', 200, NULL, NULL, 200, 'Y'),
	(7, 'Transfer', 200, NULL, NULL, 200, 'Y'),
	(8, 'Migration', 200, NULL, NULL, 200, 'Y'),
	(9, 'Professional', 200, NULL, NULL, 200, 'Y'),
	(10, 'Degree Certiicate', 1600, NULL, NULL, 1600, 'Y');
/*!40000 ALTER TABLE `certificate_fee` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.city
DROP TABLE IF EXISTS `city`;
CREATE TABLE IF NOT EXISTS `city` (
  `city_id` int(11) NOT NULL AUTO_INCREMENT,
  `city` varchar(255) NOT NULL,
  `state_code` varchar(255) NOT NULL,
  PRIMARY KEY (`city_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3395 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.city: ~3,392 rows (approximately)
/*!40000 ALTER TABLE `city` DISABLE KEYS */;
INSERT INTO `city` (`city_id`, `city`, `state_code`) VALUES
	(2200, 'Chennai', 'TN'),
	(2201, 'Coimbatore', 'TN'),
	(2202, 'Cuddalore', 'TN'),
	(2203, 'Dharmapuri', 'TN'),
	(2204, 'Dindigul', 'TN'),
	(2205, 'Erode', 'TN'),
	(2206, 'Kancheepuram', 'TN'),
	(2207, 'Karur', 'TN'),
	(2208, 'Madurai', 'TN'),
	(2209, 'Nagapattinam', 'TN'),
	(2210, 'Nagercoil', 'TN'),
	(2211, 'Namakkal', 'TN'),
	(2212, 'Perambalur', 'TN'),
	(2213, 'Pudukkottai', 'TN'),
	(2214, 'Ramanathapuram', 'TN'),
	(2215, 'Salem', 'TN'),
	(2216, 'Sivaganga', 'TN'),
	(2217, 'Thanjavur', 'TN'),
	(2218, 'Theni Allinagaram', 'TN'),
	(2219, 'Thiruvallur', 'TN'),
	(2220, 'Thiruvarur', 'TN'),
	(2221, 'Thoothukkudi', 'TN'),
	(2222, 'Tiruchirappalli', 'TN'),
	(2223, 'Tirunelveli', 'TN'),
	(2224, 'Tiruppur', 'TN'),
	(2225, 'Tiruvannamalai', 'TN'),
	(2226, 'Udhagamandalam', 'TN'),
	(2227, 'Vellore', 'TN'),
	(2228, 'Viluppuram', 'TN');

/*!40000 ALTER TABLE `city` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.class_room
DROP TABLE IF EXISTS `class_room`;
CREATE TABLE IF NOT EXISTS `class_room` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_name` varchar(100) NOT NULL,
  `campus_id` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.class_room: ~5 rows (approximately)
/*!40000 ALTER TABLE `class_room` DISABLE KEYS */;
INSERT INTO `class_room` (`id`, `room_name`, `campus_id`, `created_on`, `updated_on`, `status`) VALUES
	(1, 'Alpha', 1, '2019-01-07 19:38:39', NULL, 1),
	(2, 'Beta', 1, '2019-01-07 09:43:16', NULL, 1),
	(3, 'Auditorium', 1, '2019-01-07 09:43:38', NULL, 1),
	(4, 'Computer Lab1', 1, '2019-01-07 09:43:52', NULL, 1),
	(5, '201', 1, '2019-01-07 09:44:06', NULL, 1);
/*!40000 ALTER TABLE `class_room` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.community
DROP TABLE IF EXISTS `community`;
CREATE TABLE IF NOT EXISTS `community` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` tinytext,
  `status` enum('Y','N') DEFAULT 'Y',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.community: ~5 rows (approximately)
/*!40000 ALTER TABLE `community` DISABLE KEYS */;
INSERT INTO `community` (`id`, `name`, `status`) VALUES
	(1, 'SCHEDULED CASTES', 'Y'),
	(2, 'SCHEDULED TRIBES', 'Y'),
	(3, 'MOST BACKWARD CLASSES', 'Y'),
	(4, 'BACKWARD CLASSES', 'Y'),
	(5, 'BACKWARD CLASSES MUSLIMS', 'Y');
/*!40000 ALTER TABLE `community` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.country
DROP TABLE IF EXISTS `country`;
CREATE TABLE IF NOT EXISTS `country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(200) DEFAULT NULL,
  `country_code` varchar(100) DEFAULT NULL,
  `country_code_short` varchar(100) DEFAULT NULL,
  `newcode` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=241 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.country: 240 rows
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` (`id`, `country_name`, `country_code`, `country_code_short`, `newcode`) VALUES
        (98, 'Iceland', 'ISL', 'IS', 'IC'),
	(99, 'India', 'IND', 'IN', 'IN'),
	(100, 'Indonesia', 'IDN', 'ID', 'ID');
	
/*!40000 ALTER TABLE `country` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.courses
DROP TABLE IF EXISTS `courses`;
CREATE TABLE IF NOT EXISTS `courses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `program_id` int(22) NOT NULL,
  `degree_id` int(22) NOT NULL,
  `discipline_id` int(22) NOT NULL,
  `syllabus_id` varchar(20) NOT NULL,
  `course_group_id` varchar(20) NOT NULL,
  `course_subject_id` int(11) NOT NULL,
  `semester_id` int(22) NOT NULL,
  `course_code` varchar(50) NOT NULL,
  `course_title` varchar(255) NOT NULL,
  `order_value` tinyint(4) DEFAULT NULL,
  `theory_credit` varchar(50) NOT NULL,
  `practicle_credit` varchar(50) NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.courses: ~120 rows (approximately)
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` (`id`, `program_id`, `degree_id`, `discipline_id`, `syllabus_id`, `course_group_id`, `course_subject_id`, `semester_id`, `course_code`, `course_title`, `order_value`, `theory_credit`, `practicle_credit`, `created_on`, `updated_on`, `status`) VALUES
	(1, 1, 1, 1, '1', '1', 1, 1, 'VAN-I', 'Information Technology', 0, '4', '3', '2019-01-30 18:33:03', NULL, 1),
	(2, 1, 1, 1, '1', '1', 1, 1, 'VAN-II', 'Electrical and Electronic Engineering', 0, '4', '3', '2019-01-30 18:33:16', NULL, 1),
	(3, 1, 1, 1, '1', '1', 2, 1, 'VPY-I', 'Fashion Technology', 1, '4', '1', '2019-02-03 19:14:52', NULL, 1),
	(4, 1, 1, 1, '1', '1', 2, 1, 'VPY-II', 'Civil Engineering', 1, '4', '1', '2019-02-03 19:14:58', NULL, 1);
	
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.course_assigned_students
DROP TABLE IF EXISTS `course_assigned_students`;
CREATE TABLE IF NOT EXISTS `course_assigned_students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campus_id` int(11) NOT NULL,
  `program_id` int(11) NOT NULL,
  `degree_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `discipline_id` int(11) NOT NULL,
  `semester_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.course_assigned_students: 0 rows
/*!40000 ALTER TABLE `course_assigned_students` DISABLE KEYS */;
/*!40000 ALTER TABLE `course_assigned_students` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.course_exam_date
DROP TABLE IF EXISTS `course_exam_date`;
CREATE TABLE IF NOT EXISTS `course_exam_date` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campus_id` int(11) NOT NULL,
  `program_id` int(11) NOT NULL,
  `degree_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `semester_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `exam_date` varchar(255) NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=135 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.course_exam_date: ~54 rows (approximately)
/*!40000 ALTER TABLE `course_exam_date` DISABLE KEYS */;
INSERT INTO `course_exam_date` (`id`, `campus_id`, `program_id`, `degree_id`, `batch_id`, `semester_id`, `course_id`, `exam_date`, `created_on`, `status`) VALUES
	(81, 1, 1, 1, 1, 1, 1, '13-08-2020', '2020-01-27 12:19:26', 0),
	(82, 1, 1, 1, 1, 1, 2, '14-08-2020', '2020-01-27 12:19:26', 0),
	(83, 1, 1, 1, 1, 1, 3, '16-08-2020', '2020-01-27 12:19:26', 0),
	(84, 1, 1, 1, 1, 1, 4, '17-08-2020', '2020-01-27 12:19:26', 0),
	(85, 1, 1, 1, 1, 1, 5, '20-08-2020', '2020-01-27 12:19:26', 0),
	(86, 1, 1, 1, 1, 1, 6, '21-08-2020', '2020-01-27 12:19:26', 0),
	(87, 1, 1, 1, 1, 1, 32, '16-01-2020', '2020-01-27 12:19:26', 0),
	(88, 2, 1, 1, 1, 1, 1, '13-08-2020', '2020-01-27 12:19:54', 0),
	(89, 2, 1, 1, 1, 1, 2, '14-08-2020', '2020-01-27 12:19:54', 0),
	(90, 2, 1, 1, 1, 1, 3, '16-08-2020', '2020-01-27 12:19:54', 0),
	(91, 2, 1, 1, 1, 1, 4, '17-08-2020', '2020-01-27 12:19:54', 0);
	
/*!40000 ALTER TABLE `course_exam_date` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.course_groups
DROP TABLE IF EXISTS `course_groups`;
CREATE TABLE IF NOT EXISTS `course_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_group_code` varchar(50) NOT NULL,
  `course_group_name` varchar(100) NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.course_groups: 2 rows
/*!40000 ALTER TABLE `course_groups` DISABLE KEYS */;
INSERT INTO `course_groups` (`id`, `course_group_code`, `course_group_name`, `created_on`, `updated_on`, `status`) VALUES
	(1, 'Credit', 'Credit', '2018-08-06 12:47:14', '2018-10-20 14:23:18', 1),
	(2, 'Non-Credit', 'Non-Credit', '2018-10-20 14:23:34', NULL, 1);
/*!40000 ALTER TABLE `course_groups` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.course_subject_groups
DROP TABLE IF EXISTS `course_subject_groups`;
CREATE TABLE IF NOT EXISTS `course_subject_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_subject_name` varchar(100) NOT NULL,
  `course_subject_title` varchar(100) NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.course_subject_groups: 13 rows
/*!40000 ALTER TABLE `course_subject_groups` DISABLE KEYS */;
INSERT INTO `course_subject_groups` (`id`, `course_subject_name`, `course_subject_title`, `created_on`, `updated_on`, `status`) VALUES
	(1, 'IT', 'Information Technology', '0000-00-00 00:00:00', '2019-02-03 16:55:24', 0),
	(2, 'FT', 'Fashion Technology', '0000-00-00 00:00:00', '2019-02-03 16:55:33', 0),
	(3, 'C', 'Civil', '0000-00-00 00:00:00', '2019-02-03 16:55:45', 0);
	
/*!40000 ALTER TABLE `course_subject_groups` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.degrees
DROP TABLE IF EXISTS `degrees`;
CREATE TABLE IF NOT EXISTS `degrees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `degree_code` varchar(100) NOT NULL,
  `degree_name` varchar(100) NOT NULL,
  `discipline_id` int(11) NOT NULL,
  `program_id` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.degrees: 6 rows
/*!40000 ALTER TABLE `degrees` DISABLE KEYS */;
INSERT INTO `degrees` (`id`, `degree_code`, `degree_name`, `discipline_id`, `program_id`, `created_on`, `updated_on`, `status`) VALUES
	(1, 'B.TECH-IT', 'BACHELOR OF INFORMATION TECHNOLOGY', 1, 1, '2018-08-06 12:42:16', NULL, 1),
	(2, 'B.Tech-FT', 'B.Tech in  FASHION TECHNOLOGY', 2, 1, '2018-08-21 14:23:16', NULL, 1),', 
	(4, 'B.E-EEE', 'B.E IN Electrical and Electronic Engineering', 4, 1, '2018-08-21 14:25:23', NULL, 1),
	(5, 'B.E-CIVIL', 'B.E in Civil Engineering', 1, 2, '2018-09-14 11:30:50', NULL, 1);
/*!40000 ALTER TABLE `degrees` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.degree_map_semester
DROP TABLE IF EXISTS `degree_map_semester`;
CREATE TABLE IF NOT EXISTS `degree_map_semester` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `degree_id` int(11) DEFAULT NULL,
  `semester_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.degree_map_semester: ~20 rows (approximately)
/*!40000 ALTER TABLE `degree_map_semester` DISABLE KEYS */;
INSERT INTO `degree_map_semester` (`id`, `degree_id`, `semester_id`) VALUES
	(1, 1, 1),
	(2, 1, 4),
	(3, 1, 5),
	(4, 1, 6),
	(5, 6, 1),
	(6, 6, 4),
	(7, 6, 5),
	(8, 6, 6),
	(9, 2, 3),
	(10, 2, 8),
	(11, 2, 9),
	(12, 2, 10),
	(13, 3, 3),
	(14, 3, 8),
	(15, 3, 9),
	(16, 3, 10),
	(17, 4, 3),
	(18, 4, 8),
	(19, 4, 9),
	(20, 4, 10);
/*!40000 ALTER TABLE `degree_map_semester` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.disciplines
DROP TABLE IF EXISTS `disciplines`;
CREATE TABLE IF NOT EXISTS `disciplines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discipline_code` varchar(255) NOT NULL,
  `discipline_name` varchar(255) NOT NULL,
  `created_on` datetime NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.disciplines: ~4 rows (approximately)
/*!40000 ALTER TABLE `disciplines` DISABLE KEYS */;
INSERT INTO `disciplines` (`id`, `discipline_code`, `discipline_name`, `created_on`, `status`) VALUES
	(1, 'B.TECH-IT, 'INFORMATION TECHNOLOGY', '2018-08-06 12:40:26', 1),
	(2, 'B.TECH-FT', 'FASHION TECHNOLOGY', '2018-08-21 13:17:56', 1),
	(3, 'B.E-EEE', 'ELECTRICAL AND ELECTRONIC ENGINEERING', '2018-08-21 13:18:48', 1),
	(4, 'B.E-CE', 'CIVIL ENGINEERING', '2018-08-21 13:20:08', 1);
/*!40000 ALTER TABLE `disciplines` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.exam_months
DROP TABLE IF EXISTS `exam_months`;
CREATE TABLE IF NOT EXISTS `exam_months` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exam_month` varchar(100) NOT NULL,
  `exam_date` date NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.exam_months: 0 rows
/*!40000 ALTER TABLE `exam_months` DISABLE KEYS */;
/*!40000 ALTER TABLE `exam_months` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.exam_slot
DROP TABLE IF EXISTS `exam_slot`;
CREATE TABLE IF NOT EXISTS `exam_slot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slot_name` varchar(100) NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.exam_slot: ~3 rows (approximately)
/*!40000 ALTER TABLE `exam_slot` DISABLE KEYS */;
INSERT INTO `exam_slot` (`id`, `slot_name`, `created_on`, `updated_on`, `status`) VALUES
	(2, '9.00 AM to 12.00 PM', '2019-01-07 20:28:23', NULL, 1),
	(3, '2.00 PM to 5.00 PM', '2019-01-07 20:28:33', NULL, 1),
	(4, '10.00 AM to 1.00 PM', '2019-01-07 20:28:46', NULL, 1);
/*!40000 ALTER TABLE `exam_slot` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.feedbacks
DROP TABLE IF EXISTS `feedbacks`;
CREATE TABLE IF NOT EXISTS `feedbacks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rate` tinyint(4) DEFAULT NULL,
  `message` text,
  `sender_id` int(11) DEFAULT NULL,
  `feedback_id` int(11) DEFAULT NULL,
  `sender_type` tinyint(4) DEFAULT NULL,
  `sender_campus` tinyint(4) DEFAULT NULL,
  `sender_program` tinyint(4) DEFAULT NULL,
  `sender_degree` tinyint(4) DEFAULT NULL,
  `sender_batch` tinyint(4) DEFAULT NULL,
  `sender_semester` tinyint(4) DEFAULT NULL,
  `sender_discipline` tinyint(4) DEFAULT NULL,
  `sender_teacher` int(11) DEFAULT NULL,
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.feedbacks: ~28 rows (approximately)
/*!40000 ALTER TABLE `feedbacks` DISABLE KEYS */;
INSERT INTO `feedbacks` (`id`, `rate`, `message`, `sender_id`, `feedback_id`, `sender_type`, `sender_campus`, `sender_program`, `sender_degree`, `sender_batch`, `sender_semester`, `sender_discipline`, `sender_teacher`, `created_on`, `status`) VALUES
	
/*!40000 ALTER TABLE `feedbacks` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.hall_tickets
DROP TABLE IF EXISTS `hall_tickets`;
CREATE TABLE IF NOT EXISTS `hall_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `college_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `board_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `month` varchar(50) NOT NULL,
  `created_on` datetime NOT NULL,
  `status` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.hall_tickets: ~0 rows (approximately)
/*!40000 ALTER TABLE `hall_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `hall_tickets` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.holiday_list
DROP TABLE IF EXISTS `holiday_list`;
CREATE TABLE IF NOT EXISTS `holiday_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `degree_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `startDate` date DEFAULT NULL,
  `endDate` date DEFAULT NULL,
  `color` varchar(100) NOT NULL DEFAULT '',
  `status` enum('Y','N') DEFAULT 'Y',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.holiday_list: ~110 rows (approximately)
/*!40000 ALTER TABLE `holiday_list` DISABLE KEYS */;
INSERT INTO `holiday_list` (`id`, `degree_id`, `name`, `startDate`, `endDate`, `color`, `status`) VALUES
	(1, 1, 'Christmas', '2020-12-25', '2020-12-25', '', 'Y'),
	(2, 1, 'Mothers day', '2020-05-12', '2020-05-12', '', 'Y'),
	(3, 1, 'Thanksgiving', '2020-11-27', '2020-11-27', '', 'Y'),
	(4, 1, 'Weekly Off', '2020-01-07', '2020-01-07', '', 'Y'),
	(5, 1, 'Weekly Off', '2020-01-14', '2020-01-14', '', 'Y'),
	(6, 1, 'Weekly Off', '2020-01-21', '2020-01-21', '', 'Y'),
	(7, 1, 'Weekly Off', '2020-01-28', '2020-01-28', '', 'Y'),
	(8, 1, 'Weekly Off', '2020-02-04', '2020-02-04', '', 'Y'),
	(9, 1, 'Weekly Off', '2020-02-11', '2020-02-11', '', 'Y'),
	(10, 1, 'Weekly Off', '2020-02-18', '2020-02-18', '', 'Y'),
	
/*!40000 ALTER TABLE `holiday_list` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.manage_feedback
DROP TABLE IF EXISTS `manage_feedback`;
CREATE TABLE IF NOT EXISTS `manage_feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `degree_id` int(11) DEFAULT NULL,
  `semester_id` int(11) DEFAULT NULL,
  `batch_id` int(11) DEFAULT NULL,
  `question` text,
  `status` enum('Y','N') DEFAULT 'Y',
  `created_on` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.manage_feedback: ~17 rows (approximately)
/*!40000 ALTER TABLE `manage_feedback` DISABLE KEYS */;
INSERT INTO `manage_feedback` (`id`, `degree_id`, `semester_id`, `batch_id`, `question`, `status`, `created_on`, `created_by`) VALUES
	(3, 1, 1, 1, 'How was your semester exam Rate it yourself', 'N', '2019-02-11 20:13:32', 1),
	(5, 1, 1, 1, 'How was the question paper Rate it from 1 to 5', 'Y', '2018-12-28 12:04:15', 1),
	(6, 1, 1, 1, 'Delivering subject(objective and coverage)', 'Y', '2019-02-06 11:22:53', 1),
	(7, 1, 1, 1, 'Use of audio - visual aids', 'Y', '2019-02-06 11:22:53', 1),
	(8, 1, 1, 1, 'Supply of course materials', 'Y', '2019-02-06 11:22:53', 1),
	(9, 1, 1, 1, 'Clarity of expression', 'Y', '2019-02-06 11:22:53', 1),
	(10, 1, 1, 1, 'Interaction with students in classroom', 'Y', '2019-02-06 11:22:53', 1),
	(11, 1, 1, 1, 'Style of teaching', 'Y', '2019-02-06 11:22:53', 1),
	(12, 1, 1, 1, 'Summarisation of previous class lectures', 'Y', '2019-02-06 11:22:53', 1),
	(13, 1, 1, 1, 'Encouraging classroom discussion', 'Y', '2019-02-06 11:22:53', 1),
	(14, 1, 1, 1, 'Accepting suggestion', 'Y', '2019-02-06 11:22:53', 1),
	(15, 1, 1, 1, 'Impartial student evaluation', 'Y', '2019-02-06 11:22:53', 1),
	(16, 1, 1, 1, 'Punctuality', 'Y', '2019-02-06 11:22:53', 1),
	(17, 1, 1, 1, 'Taking care of low performing students', 'Y', '2019-02-06 11:22:53', 1),
	(18, 1, 1, 1, 'Cordiality with students', 'Y', '2019-02-06 11:22:53', 1),
	(19, 1, 1, 1, 'Motivation of students', 'Y', '2019-02-06 11:22:53', 1),
	(20, 1, 1, 1, 'Involvement in student activities', 'Y', '2019-02-06 11:22:53', 1);
/*!40000 ALTER TABLE `manage_feedback` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.marks
DROP TABLE IF EXISTS `marks`;
CREATE TABLE IF NOT EXISTS `marks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `college_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `board_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `exam_type` varchar(50) NOT NULL,
  `created_on` datetime NOT NULL,
  `status` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.marks: ~0 rows (approximately)
/*!40000 ALTER TABLE `marks` DISABLE KEYS */;
/*!40000 ALTER TABLE `marks` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.messages
DROP TABLE IF EXISTS `messages`;
CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `send_to` tinyint(4) NOT NULL,
  `send_by` int(11) DEFAULT NULL,
  `sender_name` varchar(100) DEFAULT NULL,
  `message` text,
  `date` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.messages: ~16 rows (approximately)
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` (`id`, `user_id`, `name`, `mobile`, `send_to`, `send_by`, `sender_name`, `message`, `date`, `time`, `created_on`) VALUES
	(2, 98, 'AASHIKA K', 9635504472, 1, 0, '', '', '2018-11-13', '00:20:18', '0000-00-00 00:00:00'),
	(3, 99, 'ABHOORVAN A', 8470959210, 1, 0, '', '', '2018-11-13', '00:20:18', '0000-00-00 00:00:00'),
	(4, 98, 'AASHIKA K', 9635504472, 1, 1, '', 'testttt', '2018-11-13', '00:20:18', '0000-00-00 00:00:00'),
	(5, 99, 'ABHOORVAN A', 8470959210, 1, 1, '', 'testttt', '2018-11-13', '00:20:18', '0000-00-00 00:00:00'),
	(6, 98, 'AASHIKA K', 9635504472, 1, 1, '', 'testttt', '2018-11-13', '00:20:18', '0000-00-00 00:00:00'),
	(7, 99, 'ABHOORVAN A', 8470959210, 1, 1, '', 'testttt', '2018-11-13', '00:20:18', '0000-00-00 00:00:00'),
	(8, 98, 'AASHIKA K', 9635504472, 1, 1, '', 'testtt', '2018-11-13', '00:20:18', '0000-00-00 00:00:00'),
	(9, 99, 'ABHOORVAN A', 8470959210, 1, 1, '', 'testtt', '2018-11-13', '00:20:18', '0000-00-00 00:00:00'),
	(10, 98, 'AASHIKA K', 9635504472, 1, 1, '', 'test me', '2018-11-13', '00:20:18', '0000-00-00 00:00:00'),
	(11, 99, 'ABHOORVAN A', 8470959210, 1, 1, '', 'test me', '2018-11-13', '00:20:18', '0000-00-00 00:00:00'),
	(12, 98, 'AASHIKA K', 9891825838, 0, 1, 'Tanuvas Admin', 'tettt', '2018-11-20', '13:37:40', NULL),
	(13, 99, 'ABHOORVAN A', 8470959210, 0, 1, 'Tanuvas Admin', 'tettt', '2018-11-20', '13:37:42', NULL),
	(14, 98, 'AASHIKA K', 9891825838, 1, 572, 'Tanuvas Teacher', 'hello', '2018-11-22', '15:47:30', NULL),
	(15, 572, 'Tanuvas', 9635504472, 2, 1, 'Tanuvas Admin', 'test me', '2018-11-22', '16:09:48', NULL),
	(16, 575, 'DTeacher', 9635504472, 2, 1, 'Tanuvas Admin', 'tessss', '2018-11-26', '08:14:47', NULL),
	(17, 98, 'AASHIKA K', 8248835206, 1, 1, 'Tanuvas Admin', 'Dear Student,\r\nYou have not paid your semester fees. Please pay the outstanding 1888 through TANUVAS online portal', '2018-12-11', '11:45:44', NULL);
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.payments
DROP TABLE IF EXISTS `payments`;
CREATE TABLE IF NOT EXISTS `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(255) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `customer_mobile` varchar(255) NOT NULL,
  `customer_billing_address` varchar(255) NOT NULL,
  `customer_account` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `currency` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `clientcode` varchar(255) NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `login_user_id` int(11) DEFAULT NULL,
  `date` varchar(255) NOT NULL,
  `signature` text NOT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `semester_id` varchar(255) DEFAULT NULL,
  `program_id` int(11) DEFAULT NULL,
  `payment_type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.payments: ~40 rows (approximately)
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` (`id`, `customer_name`, `customer_email`, `customer_mobile`, `customer_billing_address`, `customer_account`, `user_name`, `user_password`, `product_id`, `currency`, `amount`, `clientcode`, `transaction_id`, `login_user_id`, `date`, `signature`, `created_date`, `semester_id`, `program_id`, `payment_type`) VALUES
	(1, 'Test Name', 'test@test.com', '9999999999', 'Mumbai', '639827', '197', 'Test@123', 'NSE', 'INR', '30', 'MTIz', '532715', NULL, '11/11/2018%2008:11:34', '2f28f04fbd950eecb5d68340f863a3e98269030365f300648697e1b153920b760c45437d09d436ef46257a97aebbf9ca50f8fc1a6bde147580097f23d41a3451', '2018-11-11 20:16:34', NULL, NULL, ''),
	(2, 'Test Name', 'test@test.com', '9999999999', 'Mumbai', '639827', '197', 'Test@123', 'NSE', 'INR', '30', 'MTIz', '517182', NULL, '11/11/2018%2008:11:37', '4d23e5f0bd41fb046953d304c185f0494ca8d5267d0cae8a8cb04d443f4ad8d8b64dc63613441a550399a60249e81dd133d9b0f39e8060c173996b1b3dbcb7ac', '2018-11-11 20:27:37', NULL, NULL, ''),
	(3, 'Test Name', 'test@test.com', '9999999999', 'Mumbai', '639827', '98', 'Test@123', 'NSE', 'INR', '30', 'MTIz', '975617', 98, '11/11/2018%2008:11:12', '2cba277560e622ac18acbe8b7d716c4fe795054c953fd1e536893b8ae8e4c6b4a8430c241b818575e7cf599e2f935874690e16261cd52a53154f539e68e45e23', '2018-11-11 20:30:12', NULL, NULL, '');
	
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.payments_response
DROP TABLE IF EXISTS `payments_response`;
CREATE TABLE IF NOT EXISTS `payments_response` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mmp_txn` varchar(255) DEFAULT NULL,
  `mer_txn` varchar(255) DEFAULT NULL,
  `amt` varchar(255) DEFAULT NULL,
  `prod` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `bank_txn` varchar(255) DEFAULT NULL,
  `f_code` varchar(255) DEFAULT NULL,
  `clientcode` varchar(255) DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `auth_code` varchar(255) DEFAULT NULL,
  `ipg_txn_id` varchar(255) DEFAULT NULL,
  `merchant_id` varchar(255) DEFAULT NULL,
  `desc` varchar(255) DEFAULT NULL,
  `udf9` varchar(255) DEFAULT NULL,
  `discriminator` varchar(255) DEFAULT NULL,
  `surcharge` varchar(255) DEFAULT NULL,
  `CardNumber` varchar(255) DEFAULT NULL,
  `udf1` varchar(255) DEFAULT NULL,
  `udf2` varchar(25) DEFAULT NULL,
  `udf3` varchar(255) DEFAULT NULL,
  `udf4` varchar(255) DEFAULT NULL,
  `udf5` varchar(255) DEFAULT NULL,
  `udf6` varchar(255) DEFAULT NULL,
  `signature` text,
  `user_id` int(11) DEFAULT NULL,
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.payments_response: ~18 rows (approximately)
/*!40000 ALTER TABLE `payments_response` DISABLE KEYS */;
INSERT INTO `payments_response` (`id`, `mmp_txn`, `mer_txn`, `amt`, `prod`, `date`, `bank_txn`, `f_code`, `clientcode`, `bank_name`, `auth_code`, `ipg_txn_id`, `merchant_id`, `desc`, `udf9`, `discriminator`, `surcharge`, `CardNumber`, `udf1`, `udf2`, `udf3`, `udf4`, `udf5`, `udf6`, `signature`, `user_id`, `created_on`) VALUES
	(5, '100002167147', '746735', '40.00', 'NSE', 'Tue Nov 13 17:38:11 IST 2018', '123123', 'Ok', '123', 'ATOM PG', '323232', '0118317277250', '197', 'Transction Success', 'null', 'CC', '0.00', '401288XXXXXX1881', 'Test Name', 'test@test.com', '9999999999', 'Mumbai', 'null', 'null', 'd94affc91133f777bdcb2f73d40e9530bc610599adb24f1090e48f99497a618c625930cd5f49fc7ea51de231c3073f111cadbb17a4cc376fd2071fb8e6b7ce68', 98, '2018-11-13 18:16:49'),
	(6, '100002515027', '648713', '300.00', 'NSE', 'Sat Dec 08 11:04:55 IST 2018', '123123', 'Ok', '123', 'ATOM PG', '323232', '0118342280253', '197', 'Transction Success', 'null', 'CC', '0.00', '401288XXXXXX1881', 'Test Name', 'test@test.com', '9999999999', 'Mumbai', 'null', 'null', 'ed0e89bd9227796766c0d42d2540fb9bddc96401edc1c0d395993e1779084d8b66f83db964d6c3a33cd19851ce5b0ed9801208199be7885ae7414f7ba7de2558', 98, '2018-12-08 11:12:54'),
	(7, '100002515033', '28382', '150.00', 'NSE', 'Sat Dec 08 11:23:22 IST 2018', '123123', 'Ok', '123', 'ATOM PG', '323232', '0118342280257', '197', 'Transction Success', 'null', 'CC', '0.00', '401288XXXXXX1881', 'Test Name', 'test@test.com', '9999999999', 'Mumbai', 'null', 'null', '17d741c61f0102da140e4031c3dde2ff77e2502f72ee5805a1608fef94487391a916baaef98363c6899cec73e6b9fd805f2ac32ad794c519040d36d9b833d4d9', 98, '2018-12-08 11:26:38'),
	(8, '100002515034', '570740', '199.00', 'NSE', 'Sat Dec 08 11:24:48 IST 2018', '123123', 'Ok', '123', 'ATOM PG', '323232', '0118342280258', '197', 'Transction Success', 'null', 'CC', '0.00', '401288XXXXXX1881', 'Test Name', 'test@test.com', '9999999999', 'Mumbai', 'null', 'null', '995b5aa875731fc4e5c8736a8a611ba09285c4590e24842d6e89e198b3ba60def6ae3b2bb0ed263aad0e7d4b1abb1661e2ba82698756c410f802e6ca1cbe26ec', 98, '2018-12-08 11:28:04'),
	(9, '0', '177887', '499.0000', 'NSE', 'Sat Dec 08 11:59:26 IST 2018', 'NA', 'C', '123', 'NA', NULL, NULL, '197', 'Cancel by User', 'null', 'NA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'af8df658be8a81b9e3b0a51fabe4858fe9c138fc4d899cde73ced390dea2a4a4847f0407fb3ba7ceff32fbbd9e4932088151e3af7bc2abb1928b3ce5f1574823', 98, '2018-12-08 12:02:41'),
	(10, '0', '177887', '499.0000', 'NSE', 'Sat Dec 08 11:59:26 IST 2018', 'NA', 'C', '123', 'NA', NULL, '177887', '197', 'Cancel by User', 'null', 'NA', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '2018-12-08 12:15:57'),
	(11, '100002515051', '98633', '999.00', 'NSE', 'Sat Dec 08 12:18:02 IST 2018', '123123', 'Ok', '123', 'ATOM PG', '323232', '0118342280266', '197', 'Transction Success', 'null', 'CC', '0.00', '401288XXXXXX1881', 'Test Name', 'test@test.com', '9999999999', 'Mumbai', 'null', 'null', '6558e39417e6e99ed36354323eb4023b155364abd14f3de9f268b018788d169becf788364f2e7304ecc377c29139108e777f2d2c1e1832eeede0070481814e83', 98, '2018-12-08 12:21:18'),
	(12, '100002515060', '195954', '799.00', 'NSE', 'Sat Dec 08 12:50:48 IST 2018', '123123', 'Ok', '123', 'ATOM PG', '323232', '0118342280268', '197', 'Transction Success', 'null', 'CC', '0.00', '401288XXXXXX1881', 'Test Name', 'test@test.com', '9999999999', 'Mumbai', 'null', 'null', 'd7bff32fdd94ee0a28c7b68f82150bf1923dbe6b12073c2386b2a6d787f6aa3cf5dd9e669dcfefc8edea20f922a3b3b90b7e9afbad60bd120348c270798b6f6f', 98, '2018-12-08 12:54:04'),
	(13, '100002515061', '532532', '999.00', 'NSE', 'Sat Dec 08 12:53:53 IST 2018', '123123', 'Ok', '123', 'ATOM PG', '323232', '0118342280269', '197', 'Transction Success', 'null', 'CC', '0.00', '401288XXXXXX1881', 'Test Name', 'test@test.com', '9999999999', 'Mumbai', 'null', 'null', '430f1060fc48688401702aa764d953617c0ff0262ed533a5df63d7850c01ed69d28c8875808b8503adc431ce9e169b546834c95aa49e64747d78062ebd6f458a', 98, '2018-12-08 12:57:08'),
	(14, '100002517021', '937867', '599.00', 'NSE', 'Mon Dec 10 11:13:44 IST 2018', '123123', 'F', '123', 'ATOM PG', '323232', '0118344280307', '197', 'Transction Failure', 'null', 'CC', '0.00', '401288XXXXXX1881', 'Test Name', 'test@test.com', '9999999999', 'Mumbai', 'null', 'null', 'f5cdad8a9454af25adddacb22b61726a990420d46e5f169aee06cb06569b8c162302ec8ceefb4a4f86b71ccdc0ea24ba3f139979cad49a0b7573482a896da4e8', 98, '2018-12-10 11:17:02'),
	(15, '100002517021', '937867', '599.00', 'NSE', 'Mon Dec 10 11:13:44 IST 2018', '123123', 'F', '123', 'ATOM PG', NULL, '937867', '197', 'Transction Failure', 'null', 'CC', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '2018-12-10 11:20:57'),
	(16, '100002517027', '916657', '199.00', 'NSE', 'Mon Dec 10 11:22:48 IST 2018', '123123', 'Ok', '123', 'ATOM PG', '323232', '0118344280308', '197', 'Transction Success', 'null', 'CC', '0.00', '401288XXXXXX1881', 'Test Name', 'test@test.com', '9999999999', 'Mumbai', 'null', 'null', 'e77a4a96ad62ee7fe15858bce3f934a62f00861aebb946a13fcdf7f395eb63bb38d6cd5ce33322ff764f68a7b675c42a801d94238ddcba11e135c9065eb1ecd7', 98, '2018-12-10 11:26:06'),
	(17, '100002531076', '732575', '899.00', 'NSE', 'Wed Dec 12 10:35:45 IST 2018', '123123', 'Ok', '123', 'ATOM PG', '323232', '0118346280618', '197', 'Transction Success', 'null', 'CC', '0.00', '401288XXXXXX1881', 'Test Name', 'test@test.com', '9999999999', 'Mumbai', 'null', 'null', '6379a709e60fba8a27ba69ac3a591a076dd43686e2f3771cb5e3807e38cdbf1aa32d4f6af66750800d234d24d14dc41d47fee0e2540baf063c3249c1d6e15b9f', 98, '2018-12-12 10:39:06'),
	(18, '100002531078', '274231', '144.00', 'NSE', 'Wed Dec 12 10:39:06 IST 2018', '123123', 'Ok', '123', 'ATOM PG', '323232', '0118346280619', '197', 'Transction Success', 'null', 'CC', '0.00', '401288XXXXXX1881', 'Test Name', 'test@test.com', '9999999999', 'Mumbai', 'null', 'null', '67c5c8270f07ef32b47c557fb05d33e16bd24664f9cc2ce6808e78d37d4af03b10d43b9378cd5ab544ff789f34776a37c2a648299627885ff7883fd0e3a5a60b', 98, '2018-12-12 10:42:27'),
	(19, '100002547067', '53193', '999.00', 'NSE', 'Thu Dec 13 10:28:31 IST 2018', '123123', 'Ok', '123', 'ATOM PG', '323232', '0118347280841', '197', 'Transction Success', 'null', 'CC', '0.00', '401288XXXXXX1881', 'Test Name', 'test@test.com', '9999999999', 'Mumbai', 'null', 'null', 'f4428516184bddeb87d50821a54d40b695502272d413aac9001d631b3d67ba6ce84ce6f98aeb40252694c7c1803e0cbd9959271b125be90afdc69a0eb7130a26', 98, '2018-12-13 10:31:53'),
	(20, '100002603069', '179902', '200.00', 'NSE', 'Thu Dec 20 17:19:17 IST 2018', '123123', 'Ok', '123', 'ATOM PG', '323232', '0118354281533', '197', 'Transction Success', 'null', 'CC', '0.00', '401288XXXXXX1881', 'Test Name', 'test@test.com', '9999999999', 'Mumbai', 'null', 'null', '5556a89e305ae664f5af92db46065f45d53f19400293266de37faeb371504e20bbb700bd72c66ada4f5cc40c7547342d7a6743e5860f7a6f061e3b1993ae664e', 98, '2018-12-20 17:22:39'),
	(21, '100002753292', '920838', '500.00', 'NSE', 'Sun Jan 13 16:58:15 IST 2019', '123123', 'Ok', '123', 'ATOM PG', '323232', '0119013284158', '197', 'Transction Success', 'null', 'CC', '0.00', '401288XXXXXX1881', 'Test Name', 'test@test.com', '9999999999', 'Mumbai', 'null', 'null', 'cb99bfcd4f95db0e692be067dfa119d207813c066a8a12b0be4bf77b46756e81b4cc7e5721c7487f5a19391f3072d0888f9a2a29f0eed0bbc62a291f9b862eaf', 98, '2019-01-13 17:01:28'),
	(22, '100002961184', '338013', '200.00', 'NSE', 'Wed Feb 06 16:23:45 IST 2019', '123123', 'Ok', '123', 'ATOM PG', '323232', '0119037287201', '197', 'Transction Success', 'null', 'CC', '0.00', '401288XXXXXX1881', 'Test Name', 'test@test.com', '9999999999', 'Mumbai', 'null', 'null', '8775232bdbd4d48d8309c162bac608a4f84d04f80f8045e6a6a6d36717db7124bc102f4c3a3116c5be01d6a7c43390e8ffcb8ec722eb58060097351d0974483e', 98, '2019-02-06 16:26:54');
/*!40000 ALTER TABLE `payments_response` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.permission
DROP TABLE IF EXISTS `permission`;
CREATE TABLE IF NOT EXISTS `permission` (
  `permission_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `page_id` varchar(11) NOT NULL,
  PRIMARY KEY (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.permission: ~0 rows (approximately)
/*!40000 ALTER TABLE `permission` DISABLE KEYS */;
/*!40000 ALTER TABLE `permission` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.previous_semester_marks
DROP TABLE IF EXISTS `previous_semester_marks`;
CREATE TABLE IF NOT EXISTS `previous_semester_marks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `total_marks` varchar(100) DEFAULT NULL,
  `total_credit_points` varchar(100) DEFAULT NULL,
  `total_credits` varchar(100) DEFAULT NULL,
  `total_grade_point_average` varchar(100) DEFAULT NULL,
  `campus_id` int(11) DEFAULT NULL,
  `program_id` int(11) DEFAULT NULL,
  `degree_id` int(11) DEFAULT NULL,
  `semester_id` int(11) DEFAULT NULL,
  `batch_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=140 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.previous_semester_marks: 139 rows
/*!40000 ALTER TABLE `previous_semester_marks` DISABLE KEYS */;
INSERT INTO `previous_semester_marks` (`id`, `total_marks`, `total_credit_points`, `total_credits`, `total_grade_point_average`, `campus_id`, `program_id`, `degree_id`, `semester_id`, `batch_id`, `student_id`) VALUES
	(1, '500', '145.8', '20', '7.29', 6, 1, 4, 2, 1, 535),
	(2, '485', '141.3', '20', '7.07', 6, 1, 4, 2, 1, 536),
	(3, '0', '0', '18', '0.00', 1, 1, 1, 1, 1, 98),
	(4, '', '', '', '0.00', 1, 1, 1, 1, 1, 99),
	(5, '0', '0', '18', '0.00', 1, 1, 1, 1, 1, 100),
	(6, '144.8', '28.96', '13', '2.23', 1, 1, 1, 1, 1, 101),
	(7, '144.6', '28.92', '13', '2.22', 1, 1, 1, 1, 1, 102),
	(8, '162', '32.4', '13', '2.49', 1, 1, 1, 1, 1, 103),
	(9, '117.4', '23.48', '13', '1.81', 1, 1, 1, 1, 1, 104),
	(10, '48.2', '9.64', '13', '0.74', 1, 1, 1, 1, 1, 105);
	
/*!40000 ALTER TABLE `previous_semester_marks` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.programs
DROP TABLE IF EXISTS `programs`;
CREATE TABLE IF NOT EXISTS `programs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `program_code` varchar(50) NOT NULL,
  `program_name` varchar(100) NOT NULL,
  `program_description` varchar(150) NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.programs: 2 rows
/*!40000 ALTER TABLE `programs` DISABLE KEYS */;
INSERT INTO `programs` (`id`, `program_code`, `program_name`, `program_description`, `created_on`, `updated_on`, `status`) VALUES
	(1, 'UG', 'Under Graduate', 'Under Graduate', '2018-08-06 12:10:10', NULL, 1),
	(2, 'PG', 'Post Graduate', 'Post Graduate', '2018-09-14 11:29:35', NULL, 1);
/*!40000 ALTER TABLE `programs` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.results
DROP TABLE IF EXISTS `results`;
CREATE TABLE IF NOT EXISTS `results` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `campus_id` int(11) NOT NULL,
  `program_id` int(11) NOT NULL,
  `degree_id` int(11) NOT NULL,
  `semester_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `theory_credit` tinyint(4) DEFAULT NULL,
  `practicle_credit` tinyint(4) DEFAULT NULL,
  `theory_internal1` varchar(50) DEFAULT NULL,
  `theory_internal2` varchar(50) DEFAULT NULL,
  `theory_internal3` varchar(50) DEFAULT NULL,
  `theory_internal` varchar(50) DEFAULT NULL,
  `theory_paper1` varchar(50) DEFAULT NULL COMMENT '/3',
  `theory_paper2` varchar(50) DEFAULT NULL COMMENT '/3',
  `sum_internal_practical` varchar(50) DEFAULT NULL,
  `practical_internal` varchar(50) DEFAULT NULL,
  `theory_external` varchar(50) DEFAULT NULL,
  `practical_external` varchar(50) DEFAULT NULL,
  `marks_sum` varchar(50) DEFAULT NULL,
  `sum_internal` varchar(50) DEFAULT NULL,
  `pass_condition1` varchar(50) DEFAULT NULL,
  `pass_condition2` varchar(50) DEFAULT NULL,
  `external_sum` varchar(50) DEFAULT NULL,
  `ncc_status` tinyint(4) DEFAULT NULL,
  `course_group_id` int(11) DEFAULT NULL,
  `passfail_status` varchar(50) DEFAULT NULL,
  `percentval` varchar(50) DEFAULT NULL,
  `gradeval` varchar(50) DEFAULT NULL,
  `creditval` varchar(50) DEFAULT NULL,
  `credithour` varchar(50) DEFAULT NULL,
  `dstatus` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=942 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.results: 941 rows
/*!40000 ALTER TABLE `results` DISABLE KEYS */;
INSERT INTO `results` (`id`, `student_id`, `campus_id`, `program_id`, `degree_id`, `semester_id`, `batch_id`, `course_id`, `theory_credit`, `practicle_credit`, `theory_internal1`, `theory_internal2`, `theory_internal3`, `theory_internal`, `theory_paper1`, `theory_paper2`, `sum_internal_practical`, `practical_internal`, `theory_external`, `practical_external`, `marks_sum`, `sum_internal`, `pass_condition1`, `pass_condition2`, `external_sum`, `ncc_status`, `course_group_id`, `passfail_status`, `percentval`, `gradeval`, `creditval`, `credithour`, `dstatus`) VALUES
	(1, 535, 6, 1, 4, 2, 1, 23, 3, 1, NULL, NULL, NULL, '12', NULL, NULL, '24', '12', '34', NULL, '58', NULL, '24', '34', NULL, NULL, 1, 'FAIL', '58.00', '5.80', '23.20', '4', 1),
	(2, 535, 6, 1, 4, 2, 1, 24, 2, 1, NULL, NULL, NULL, '23', NULL, NULL, '36', '13', '23', NULL, '59', NULL, '36', '23', NULL, NULL, 1, 'FAIL', '59.00', '5.90', '17.70', '3', 0),
	(3, 535, 6, 1, 4, 2, 1, 25, 2, 1, NULL, NULL, NULL, '12', NULL, NULL, '26', '14', '36', NULL, '62', NULL, '26', '36', NULL, NULL, 1, 'PASS', '62.00', '6.20', '18.60', '3', 0),
	(4, 535, 6, 1, 4, 2, 1, 26, 2, 1, NULL, NULL, NULL, '23', NULL, NULL, '35', '12', '12', NULL, '47', NULL, '35', '12', NULL, NULL, 1, 'FAIL', '47.00', '4.70', '14.10', '3', 0),
	(5, 535, 6, 1, 4, 2, 1, 27, 1, 1, NULL, NULL, NULL, '23', NULL, NULL, '35', '12', '23', NULL, '58', NULL, '35', '23', NULL, NULL, 1, 'FAIL', '58.00', '5.80', '11.60', '2', 0),
	(6, 535, 6, 1, 4, 2, 1, 28, 2, 1, NULL, NULL, NULL, '23', NULL, NULL, '35', '12', '32', NULL, '67', NULL, '35', '32', NULL, NULL, 1, 'PASS', '67.00', '6.70', '20.10', '3', 0),
	(7, 535, 6, 1, 4, 2, 1, 29, 2, 1, NULL, NULL, NULL, '23', NULL, NULL, '36', '13', '27', NULL, '63', NULL, '36', '27', NULL, NULL, 1, 'PASS', '63.00', '6.30', '18.90', '3', 0),
	(8, 535, 6, 1, 4, 2, 1, 30, 2, 0, NULL, NULL, NULL, '23', NULL, NULL, '35', '12', '29', NULL, '64', NULL, '35', '29', NULL, NULL, 1, 'PASS', '64.00', '6.40', '12.80', '2', 0),
	(9, 536, 6, 1, 4, 2, 1, 23, 3, 1, NULL, NULL, NULL, '27', NULL, NULL, '41', '14', '35', NULL, '76', NULL, '41', '35', NULL, NULL, 1, 'PASS', '76.00', '7.60', '30.40', '4', 0),
	(10, 536, 6, 1, 4, 2, 1, 24, 2, 1, NULL, NULL, NULL, '25', NULL, NULL, '39', '14', '26', NULL, '65', NULL, '39', '26', NULL, NULL, 1, 'PASS', '65.00', '6.50', '19.50', '3', 0);
	
	
/*!40000 ALTER TABLE `results` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.role
DROP TABLE IF EXISTS `role`;
CREATE TABLE IF NOT EXISTS `role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.role: ~11 rows (approximately)
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` (`id`, `role_name`, `status`) VALUES
	(1, 'Student', 1),
	(2, 'Teacher', 1),
	(3, 'User', 1),
	(4, 'Subadmin', 1),
	(6, 'Alumini Student', 1),
	(7, 'Faculty Admin(HOD)', 1),
	(8, 'Junior Admin', 1),
	(9, 'Faculty Admin (COE)', 1),
	(10, 'Faculty Admin (VC)', 1),
	(11, 'Faculty Admin (Registrar)', 1),
	(12, 'Faculty Admin (Dean)', 1);
/*!40000 ALTER TABLE `role` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.semesters
DROP TABLE IF EXISTS `semesters`;
CREATE TABLE IF NOT EXISTS `semesters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `semester_code` varchar(50) NOT NULL,
  `semester_name` varchar(50) NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.semesters: 9 rows
/*!40000 ALTER TABLE `semesters` DISABLE KEYS */;
INSERT INTO `semesters` (`id`, `semester_code`, `semester_name`, `created_on`, `updated_on`, `status`) VALUES
	(1, 'IABE', 'First Professional Year', '2018-08-06 12:30:18', NULL, 1),
	(2, 'II Final', 'II Semester Final Examination', '2018-08-21 14:29:51', '2018-08-22 12:32:32', 0),
	(3, 'I', 'First Semester', '2018-11-26 17:10:06', NULL, 1),
	(4, 'IABE', 'Second Professional Year', '2018-12-05 17:50:24', NULL, 1),
	(5, 'IABE', 'Third Professional Year', '2018-12-05 17:50:50', NULL, 1),
	(6, 'IABE', 'Fourth Professional Year', '2018-12-05 17:51:24', NULL, 1),
	(8, 'II', 'Second Semester', '0000-00-00 00:00:00', NULL, 1),
	(9, 'III', 'Third Semester', '0000-00-00 00:00:00', NULL, 1),
	(10, 'IV', 'Fourth Semester', '0000-00-00 00:00:00', NULL, 1);
/*!40000 ALTER TABLE `semesters` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.sms_delivery
DROP TABLE IF EXISTS `sms_delivery`;
CREATE TABLE IF NOT EXISTS `sms_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` text,
  `message` text,
  `sent_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `responseCode` text,
  `msgid` varchar(50) DEFAULT NULL,
  `response` text,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.sms_delivery: ~71 rows (approximately)
/*!40000 ALTER TABLE `sms_delivery` DISABLE KEYS */;
INSERT INTO `sms_delivery` (`id`, `phone`, `message`, `sent_date`, `responseCode`, `msgid`, `response`, `user_id`) VALUES
	(1, '9884866254,8056544229', 'Dear+Sankar%2FAjith%2C%0D%0AYour+Payment+for+Anatomy+successully+done+with+payment+ID+121212121212.+Please+quote+this+ID+for+any+clearification.', '2018-12-10 11:01:09', 'Message SuccessFully Submitted', NULL, '[{"responseCode":"Message SuccessFully Submitted"},{"msgid":"c3d2f5e0-fc3c-11e8-877a-d31ac1a3da8f"}]', 98),
	(2, '9884866254,8056544229', 'Dear+Sankar%2FAjith%2C%0D%0AYour+Payment+for+Anatomy+successully+done+with+payment+ID+121212121212.+Please+quote+this+ID+for+any+clearification.', '2018-12-10 11:02:16', 'Message SuccessFully Submitted', 'ebda0015-fc3c-11e8-877a-093df0c08cc9', '[{"responseCode":"Message SuccessFully Submitted"},{"msgid":"ebda0015-fc3c-11e8-877a-093df0c08cc9"}]', 98),
	(3, '8056544229', 'Dear+AASHIKA+K%2C%3Cbr%3EYour+Payment+Duplicate+Certificate+Fee+for+Second+Professional+Year++failed+duo+to+Transction+Failure.+with+payment+ID+937867.+Please+quote+this+ID+for+any+clearification.', '2018-12-10 11:20:57', 'Message SuccessFully Submitted', '386144433', '[{"responseCode":"Message SuccessFully Submitted"},{"msgid":"386144433"}]', 98),
	(4, '8056544229', 'Dear+AASHIKA+K%2C%0AYour+Payment+Duplicate+Certificate+Fee+for+Second+Professional+Year++failed+due+to+Transction+Failure.+with+payment+ID+937867.+Please+quote+this+ID+for+any+clearification.', '2018-12-10 11:22:40', 'Message SuccessFully Submitted', '386144690', '[{"responseCode":"Message SuccessFully Submitted"},{"msgid":"386144690"}]', 98),
	(5, '8056544229', 'Dear+AASHIKA+K%2C%0AYour+Payment+Re-Evaluation+Certificate+Fee+for+Fourth+Professional+Year++is+succcessfully+done+with+payment+ID+916657.+Please+quote+this+ID+for+any+clearification.', '2018-12-10 11:26:17', 'Message SuccessFully Submitted', '386145658', '[{"responseCode":"Message SuccessFully Submitted"},{"msgid":"386145658"}]', 98),
	(6, '9884866254', '', '2018-12-11 10:49:51', 'Message Too Short', NULL, '[{"responseCode":"Message Too Short"}]', 98),
	(7, '9884866254', 'Dear+AASHIKA+K%2C%0AYour+One+time+password%28OTP%29+number+is+%28E52C%29.+This+OTP+is+valid+for+15+minutes.+Don%27t+share+it+with+anyone', '2018-12-11 10:50:51', 'Message SuccessFully Submitted', '386376657', '[{"responseCode":"Message SuccessFully Submitted"},{"msgid":"386376657"}]', 98),
	(8, '9884866254', 'Dear+AASHIKA+K%2C%0AYour+One+time+password%28OTP%29+number+is+%28AD43%29.+This+OTP+is+valid+for+15+minutes.+Don%27t+share+it+with+anyone', '2018-12-11 10:55:00', 'Message SuccessFully Submitted', '386377799', '[{"responseCode":"Message SuccessFully Submitted"},{"msgid":"386377799"}]', 98),
	(9, '9884866254', 'Dear+AASHIKA+K%2C%0AYour+One+time+password%28OTP%29+number+is+%28CD38%29.+This+OTP+is+valid+for+15+minutes.+Don%27t+share+it+with+anyone', '2018-12-11 11:04:28', 'Message SuccessFully Submitted', '386383920', '[{"responseCode":"Message SuccessFully Submitted"},{"msgid":"386383920"}]', 98),
	(10, '9884866254', 'Dear+AASHIKA+K%2C%0AYour+One+time+password%28OTP%29+number+is+%286480%29.+This+OTP+is+valid+for+15+minutes.+Don%27t+share+it+with+anyone', '2018-12-11 11:04:49', 'Message SuccessFully Submitted', '386384046', '[{"responseCode":"Message SuccessFully Submitted"},{"msgid":"386384046"}]', 98);	
/*!40000 ALTER TABLE `sms_delivery` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.state
DROP TABLE IF EXISTS `state`;
CREATE TABLE IF NOT EXISTS `state` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state` varchar(255) NOT NULL,
  `state_code` varchar(255) NOT NULL,
  `country_id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.state: ~34 rows (approximately)
/*!40000 ALTER TABLE `state` DISABLE KEYS */;
INSERT INTO `state` (`id`, `state`, `state_code`, `country_id`) VALUES
	(1, 'Andaman & Nicobar', 'AN', '99'),
	(2, 'Andhra Pradesh', 'AP', '99'),
	(3, 'Arunachal Pradesh', 'AR', '99'),
	(4, 'Assam', 'AS', '99'),
	(5, 'Bihar', 'BR', '99');
	
/*!40000 ALTER TABLE `state` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.students
DROP TABLE IF EXISTS `students`;
CREATE TABLE IF NOT EXISTS `students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unique_id` varchar(255) NOT NULL,
  `program_id` int(11) NOT NULL,
  `campus_id` int(11) NOT NULL,
  `degree_id` int(11) NOT NULL,
  `semester_id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `date_of_registration` varchar(100) NOT NULL,
  `year_of_admission` varchar(100) NOT NULL,
  `middle_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `mobile_number` bigint(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `status` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.students: ~0 rows (approximately)
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
/*!40000 ALTER TABLE `students` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.students_pg_marks
DROP TABLE IF EXISTS `students_pg_marks`;
CREATE TABLE IF NOT EXISTS `students_pg_marks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campus_id` int(11) DEFAULT NULL,
  `program_id` int(11) DEFAULT NULL,
  `degree_id` int(11) DEFAULT NULL,
  `batch_id` int(11) DEFAULT NULL,
  `semester_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `internal_theory` varchar(50) DEFAULT NULL,
  `term_paper` varchar(50) DEFAULT NULL,
  `internal_practical` varchar(50) NOT NULL,
  `external_theory` varchar(50) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.students_pg_marks: 0 rows
/*!40000 ALTER TABLE `students_pg_marks` DISABLE KEYS */;
/*!40000 ALTER TABLE `students_pg_marks` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.students_ug_deflicit_marks
DROP TABLE IF EXISTS `students_ug_deflicit_marks`;
CREATE TABLE IF NOT EXISTS `students_ug_deflicit_marks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campus_id` int(11) NOT NULL,
  `program_id` int(11) NOT NULL,
  `degree_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `semester_id` int(11) NOT NULL,
  `discipline_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `course_id` varchar(50) NOT NULL,
  `deflicit_mark` varchar(100) DEFAULT NULL,
  `deflicit_range` varchar(100) DEFAULT NULL,
  `highest_marks` varchar(100) DEFAULT NULL,
  `second_highest_marks` varchar(100) DEFAULT NULL,
  `smallest_marks` varchar(100) DEFAULT NULL,
  `date_of_start` date DEFAULT NULL,
  `theory_internal1` varchar(50) DEFAULT NULL,
  `theory_internal2` varchar(50) DEFAULT NULL,
  `theory_internal3` varchar(50) DEFAULT NULL,
  `theory_internal` varchar(255) DEFAULT NULL COMMENT 'pg:Internal Theory(20)',
  `theory_paper1` varchar(100) DEFAULT NULL COMMENT 'internal practical',
  `theory_paper2` varchar(100) DEFAULT NULL COMMENT 'internal practical',
  `theory_paper3` varchar(100) DEFAULT NULL,
  `theory_paper4` varchar(100) DEFAULT NULL,
  `sum_internal_practical` varchar(100) DEFAULT NULL,
  `practical_internal` varchar(255) DEFAULT NULL COMMENT 'pg:Term Paper(10)',
  `theory_external1` varchar(255) DEFAULT NULL COMMENT 'pg:Internal Practical(50/100)',
  `theory_external2` varchar(255) DEFAULT NULL,
  `theory_external3` varchar(255) DEFAULT NULL,
  `theory_external4` varchar(255) DEFAULT NULL,
  `practical_external` varchar(255) DEFAULT NULL COMMENT 'pg:External Theory(70/100)',
  `external_sum` varchar(255) DEFAULT NULL,
  `marks_sum` varchar(50) DEFAULT NULL,
  `ncc_status` tinyint(4) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.students_ug_deflicit_marks: ~0 rows (approximately)
/*!40000 ALTER TABLE `students_ug_deflicit_marks` DISABLE KEYS */;
/*!40000 ALTER TABLE `students_ug_deflicit_marks` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.students_ug_marks
DROP TABLE IF EXISTS `students_ug_marks`;
CREATE TABLE IF NOT EXISTS `students_ug_marks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campus_id` int(11) NOT NULL,
  `program_id` int(11) NOT NULL,
  `degree_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `semester_id` int(11) NOT NULL,
  `discipline_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `course_id` varchar(50) NOT NULL,
  `highest_marks` varchar(100) DEFAULT NULL,
  `second_highest_marks` varchar(100) DEFAULT NULL,
  `smallest_marks` varchar(100) DEFAULT NULL,
  `date_of_start` date DEFAULT NULL,
  `theory_internal1` varchar(50) DEFAULT NULL,
  `theory_internal2` varchar(50) DEFAULT NULL,
  `theory_internal3` varchar(50) DEFAULT NULL,
  `theory_internal` varchar(255) DEFAULT NULL COMMENT 'pg:Internal Theory(20)',
  `theory_paper1` varchar(100) DEFAULT NULL COMMENT 'internal practical',
  `theory_paper2` varchar(100) DEFAULT NULL COMMENT 'internal practical',
  `theory_paper3` varchar(100) DEFAULT NULL,
  `theory_paper4` varchar(100) DEFAULT NULL,
  `sum_internal_practical` varchar(100) DEFAULT NULL,
  `practical_internal` varchar(255) DEFAULT NULL COMMENT 'pg:Term Paper(10)',
  `assignment_mark` varchar(255) DEFAULT NULL,
  `theory_external1` varchar(255) DEFAULT NULL COMMENT 'pg:Internal Practical(50/100)',
  `theory_external2` varchar(255) DEFAULT NULL,
  `theory_external3` varchar(255) DEFAULT NULL,
  `theory_external4` varchar(255) DEFAULT NULL,
  `practical_external` varchar(255) DEFAULT NULL COMMENT 'pg:External Theory(70/100)',
  `external_sum` varchar(255) DEFAULT NULL,
  `marks_sum` varchar(50) DEFAULT NULL,
  `ncc_status` tinyint(4) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=851 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.students_ug_marks: 850 rows
/*!40000 ALTER TABLE `students_ug_marks` DISABLE KEYS */;
INSERT INTO `students_ug_marks` (`id`, `campus_id`, `program_id`, `degree_id`, `batch_id`, `semester_id`, `discipline_id`, `student_id`, `course_id`, `highest_marks`, `second_highest_marks`, `smallest_marks`, `date_of_start`, `theory_internal1`, `theory_internal2`, `theory_internal3`, `theory_internal`, `theory_paper1`, `theory_paper2`, `theory_paper3`, `theory_paper4`, `sum_internal_practical`, `practical_internal`, `assignment_mark`, `theory_external1`, `theory_external2`, `theory_external3`, `theory_external4`, `practical_external`, `external_sum`, `marks_sum`, `ncc_status`, `created_on`, `status`) VALUES
	(1, 1, 1, 1, 1, 1, 1, 98, '1|2-1', '40', '39', '35', NULL, '35', '39', '40', '79', '56', '60', NULL, NULL, '38.67', NULL, NULL, '78', '99', NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-03 19:30:55', 0),
	(2, 1, 1, 1, 1, 1, 1, 100, '1|2-1', '40', '39', '35', NULL, '30', '31', '34', '65', '55', '49', NULL, NULL, '34.67', NULL, NULL, '100', '85', NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-03 19:30:55', 0),
	(3, 1, 1, 1, 1, 1, 1, 101, '1|2-1', '40', '39', '35', NULL, '27', '', '', '27', '', '', NULL, NULL, '0.00', NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-03 19:30:55', 0),
	(4, 1, 1, 1, 1, 1, 1, 102, '1|2-1', '40', '39', '35', NULL, '21', '', '', '21', '', '', NULL, NULL, '0.00', NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-03 19:30:55', 0),
	(5, 1, 1, 1, 1, 1, 1, 103, '1|2-1', '40', '39', '35', NULL, '15', '', '', '15', '', '', NULL, NULL, '0.00', NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-03 19:30:55', 0),
	(6, 1, 1, 1, 1, 1, 1, 104, '1|2-1', '40', '39', '35', NULL, '', '', '', '0', '', '', NULL, NULL, '0.00', NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-03 19:30:55', 0),
	(7, 1, 1, 1, 1, 1, 1, 105, '1|2-1', '40', '39', '35', NULL, '', '', '', '0', '', '', NULL, NULL, '0.00', NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-03 19:30:55', 0),
	(8, 1, 1, 1, 1, 1, 1, 106, '1|2-1', '40', '39', '35', NULL, '', '', '', '0', '', '', NULL, NULL, '0.00', NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-03 19:30:55', 0),
	(9, 1, 1, 1, 1, 1, 1, 107, '1|2-1', '40', '39', '35', NULL, '', '', '', '0', '', '', NULL, NULL, '0.00', NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-03 19:30:55', 0),
	(10, 1, 1, 1, 1, 1, 1, 108, '1|2-1', '40', '39', '35', NULL, '', '', '', '0', '', '', NULL, NULL, '0.00', NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, '2019-02-03 19:30:55', 0);
	
	
/*!40000 ALTER TABLE `students_ug_marks` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.student_assigned_courses
DROP TABLE IF EXISTS `student_assigned_courses`;
CREATE TABLE IF NOT EXISTS `student_assigned_courses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campus_id` int(11) NOT NULL,
  `program_id` int(11) NOT NULL,
  `degree_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `semester_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `exam_type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5008 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.student_assigned_courses: 2,222 rows
/*!40000 ALTER TABLE `student_assigned_courses` DISABLE KEYS */;
INSERT INTO `student_assigned_courses` (`id`, `campus_id`, `program_id`, `degree_id`, `batch_id`, `semester_id`, `student_id`, `course_id`, `exam_type`) VALUES
	(1, 1, 1, 1, 1, 1, 109, 3, NULL),
	(2, 1, 1, 1, 1, 1, 109, 4, NULL),
	(3, 1, 1, 1, 1, 1, 120, 1, NULL),
	(4, 1, 1, 1, 1, 1, 120, 2, NULL),
	(5, 1, 1, 1, 1, 1, 122, 1, NULL),
	(6, 1, 1, 1, 1, 1, 122, 2, NULL),
	(7, 1, 1, 1, 1, 1, 122, 3, NULL),
	(8, 1, 1, 1, 1, 1, 122, 4, NULL),
	(9, 1, 1, 1, 1, 1, 127, 1, NULL),
	(10, 1, 1, 1, 1, 1, 127, 2, NULL);
	
/*!40000 ALTER TABLE `student_assigned_courses` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.student_education_details
DROP TABLE IF EXISTS `student_education_details`;
CREATE TABLE IF NOT EXISTS `student_education_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `group` int(11) DEFAULT NULL,
  `board_of_examination` varchar(100) DEFAULT NULL,
  `number_of_attempts` varchar(100) DEFAULT NULL,
  `language` int(11) DEFAULT NULL,
  `english` int(11) DEFAULT NULL,
  `mathematics` int(11) DEFAULT NULL,
  `physics_theory` int(11) DEFAULT NULL,
  `physics_practical` int(11) DEFAULT NULL,
  `physics_total` int(11) DEFAULT NULL,
  `chemistry_theory` int(11) DEFAULT NULL,
  `chemistry_practical` int(11) DEFAULT NULL,
  `chemistry_total` int(11) DEFAULT NULL,
  `other_theory` int(11) DEFAULT NULL,
  `other_practical` int(11) DEFAULT NULL,
  `other_total` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `total_aggregate` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.student_education_details: ~0 rows (approximately)
/*!40000 ALTER TABLE `student_education_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_education_details` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.student_school_details
DROP TABLE IF EXISTS `student_school_details`;
CREATE TABLE IF NOT EXISTS `student_school_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `xii_school_name` varchar(255) DEFAULT NULL,
  `xii_year` varchar(255) DEFAULT NULL,
  `xii_place` varchar(255) DEFAULT NULL,
  `xii_state` varchar(255) DEFAULT NULL,
  `xi_school_name` varchar(255) DEFAULT NULL,
  `xi_year` varchar(255) DEFAULT NULL,
  `xi_place` varchar(255) DEFAULT NULL,
  `xi_state` varchar(255) DEFAULT NULL,
  `x_school_name` varchar(255) DEFAULT NULL,
  `x_year` varchar(255) DEFAULT NULL,
  `x_place` varchar(255) DEFAULT NULL,
  `x_state` varchar(255) DEFAULT NULL,
  `ix_school_name` varchar(255) DEFAULT NULL,
  `ix_year` varchar(255) DEFAULT NULL,
  `ix_place` varchar(255) DEFAULT NULL,
  `ix_state` varchar(255) DEFAULT NULL,
  `viii_school_name` varchar(255) DEFAULT NULL,
  `viii_year` varchar(255) DEFAULT NULL,
  `viii_place` varchar(255) DEFAULT NULL,
  `viii_state` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.student_school_details: ~0 rows (approximately)
/*!40000 ALTER TABLE `student_school_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_school_details` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.student_transaction_details
DROP TABLE IF EXISTS `student_transaction_details`;
CREATE TABLE IF NOT EXISTS `student_transaction_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `courses_applied` int(11) DEFAULT NULL,
  `campus_preference_1` int(11) DEFAULT NULL,
  `campus_preference_2` int(11) DEFAULT NULL,
  `campus_preference_3` int(11) DEFAULT NULL,
  `campus_preference_4` int(11) DEFAULT NULL,
  `transaction_id` int(11) DEFAULT NULL,
  `transaction_date` varchar(50) DEFAULT NULL,
  `submission_status` varchar(50) DEFAULT NULL,
  `submission_date` varchar(50) DEFAULT NULL,
  `received_status` varchar(50) DEFAULT NULL,
  `received_date` varchar(50) DEFAULT NULL,
  `candidate_status` varchar(50) DEFAULT NULL,
  `reason_for_rejection` varchar(255) DEFAULT NULL,
  `overall_rank` int(11) DEFAULT NULL,
  `community_rank` int(11) DEFAULT NULL,
  `selected_under_category` varchar(50) DEFAULT NULL,
  `selected_under_college` varchar(50) DEFAULT NULL,
  `fee_status` varchar(50) DEFAULT NULL,
  `receipt` varchar(50) DEFAULT NULL,
  `receipt_date` varchar(50) DEFAULT NULL,
  `receipt_remark` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.student_transaction_details: ~0 rows (approximately)
/*!40000 ALTER TABLE `student_transaction_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_transaction_details` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.syllabus_years
DROP TABLE IF EXISTS `syllabus_years`;
CREATE TABLE IF NOT EXISTS `syllabus_years` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `syllabus_year` varchar(100) NOT NULL,
  `program_id` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.syllabus_years: 2 rows
/*!40000 ALTER TABLE `syllabus_years` DISABLE KEYS */;
INSERT INTO `syllabus_years` (`id`, `syllabus_year`, `program_id`, `created_on`, `updated_on`, `status`) VALUES
	(1, '2017', 1, '2018-08-06 12:45:37', NULL, 1),
	(3, '2017', 2, '2018-11-26 17:02:41', NULL, 1);
/*!40000 ALTER TABLE `syllabus_years` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.tbladminmenu
DROP TABLE IF EXISTS `tbladminmenu`;
CREATE TABLE IF NOT EXISTS `tbladminmenu` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `menuname` varchar(255) DEFAULT NULL,
  `parentid` int(10) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `class` varchar(256) NOT NULL,
  `position` bigint(20) NOT NULL DEFAULT '0',
  `r_status` enum('Active','Inactive','Delete') DEFAULT 'Active',
  `is_admin` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.tbladminmenu: ~104 rows (approximately)
/*!40000 ALTER TABLE `tbladminmenu` DISABLE KEYS */;
INSERT INTO `tbladminmenu` (`id`, `menuname`, `parentid`, `url`, `class`, `position`, `r_status`, `is_admin`) VALUES
	(1, 'Dashboard', 0, 'admin/dashboard', 'fa fa-dashboard', 1, 'Active', 1),
	(2, 'Add Permission', 1, 'permissions/addPermission', 'active', 3, 'Inactive', 0),
	(3, 'Manage Users', 0, NULL, 'fa fa-users', 3, 'Active', 1),
	(4, 'Add User', 3, 'admin/addUser', '', 5, 'Active', 0),
	(5, 'Lis All User', 3, 'admin/listUser', '', 0, 'Active', 0),
	(6, 'Masters', 0, NULL, 'fa fa-database', 2, 'Active', 1),
	(7, 'Campuses', 6, 'campus/listCampus', '', 0, 'Active', 0),
	(8, 'Add campus', 6, 'campus/addCampus', 'active', 0, 'Inactive', 0),
	(9, 'Disciplines', 6, 'discipline/viewDiscipline', '', 0, 'Active', 0),
	(10, 'Add Discipline', 6, 'discipline/addDiscipline', 'active', 0, 'Inactive', 0),
	(11, 'Courses', 6, 'discipline/viewCourse', '', 0, 'Active', 0),
	(12, 'Add Course', 6, 'discipline/addCourse', 'active', 0, 'Inactive', 0),
	(13, 'Programs', 6, 'program/listProgram', '', 0, 'Active', 0),
	(14, 'Degrees', 6, 'master/listDegree', '', 0, 'Active', 0),
	(15, 'Syllabus Years', 6, 'master/listSyllabusYear', '', 0, 'Active', 0),
	(16, 'Semesters', 6, 'semester/listSemester', '', 0, 'Active', 0),
	(17, 'Course Groups', 6, 'course/listCourseGroup', '', 0, 'Active', 0),
	(18, 'Assign Management', 0, NULL, 'fa fa-plug', 5, 'Active', 1),
	(19, 'Assign Course List', 18, 'course/assignCourseList', '', 1, 'Active', 0),
	(20, 'Add Campus and Degree', 18, 'campus/campusAndDegreeList', 'active', 2, 'Active', 0),
	(21, 'Student Course Assignment', 18, 'course/studentCourseAssignment', '', 3, 'Active', 0),
	(22, 'Schedule Management', 0, NULL, 'fa fa-calendar', 7, 'Active', 1),
	(23, 'Add Time-Table', 22, 'secure/addTimeTable', '', 0, 'Inactive', 0),
	(24, 'Exam Time Table', 22, 'timetable/viewTimeTable', '', 0, 'Active', 0),
	(25, 'Generate Registration Card', 25, 'generate/generateRegistrationCard', '', 0, 'Active', 0),
	(26, 'Reports', 0, '', 'fa fa-id-card', 7, 'Active', 1),
	(27, 'Generate Registration Card', 26, 'generate/generateRegistrationCard', '', 0, 'Active', 0),
	(28, 'Role Management', 0, NULL, 'fa fa-lock', 4, 'Active', 1),
	(29, 'Assign Role', 28, 'role/assignrole', '', 0, 'Active', 0),
	(30, 'Dummy Number', 0, NULL, 'fa fa-sitemap', 6, 'Active', 1),
	(31, 'Generate Dummy Number', 30, 'dummy/generateDummy', '', 0, 'Active', 0),
	(32, 'Upload Marks', 0, '', 'fa fa-upload', 8, 'Active', 1),
	(33, 'Upload UG(Marks)', 32, 'marks/marksUpload', '', 0, 'Active', 0),
	(34, 'Upload PG(Marks-Student-wise)', 32, 'marks/marksUploadPG', '', 0, 'Inactive', 0),
	(35, 'Upload Student Excel', 3, 'admin/addStudentExcel', '', 0, 'Active', 0),
	(36, 'Class Grade Chart', 0, NULL, 'fa fa-graduation-cap', 9, 'Active', 1),
	(37, 'Course Wise Report', 36, 'grade/generateGradeChart', '', 0, 'Active', 0),
	(38, 'User Request ', 0, NULL, '', 0, 'Inactive', 1),
	(39, 'User Update Request', 3, 'profile/listRequest', '', 0, 'Active', 0),
	(40, 'Upload Student Images', 3, 'admin/addImages', '', 0, 'Active', 0),
	(41, 'Upload Marks Excel', 32, 'marks/uploadUgMarksExcel', '', 0, 'Inactive', 0),
	(42, 'Schedule Exam Date', 22, 'examdate/addExamDate', '', 0, 'Active', 0),
	(43, 'Result Management', 0, '', '', 0, 'Inactive', 1),
	(44, 'Generate Student Result', 26, 'result/generateResult', '', 0, 'Active', 0),
	(45, 'Bulk Course Assignment', 18, 'assignment/studentCourseAssignment', '', 6, 'Active', 0),
	(46, 'Update Student Marks', 32, 'marksupdate/updateStudentMarks', '', 0, 'Inactive', 0),
	(47, 'View Dashboard', 1, 'admin/dashboard', '', 0, 'Inactive', 0),
	(48, 'Upload PG(Marks)', 32, 'markspg/marksUpload', '', 0, 'Inactive', 0),
	(49, 'Batches', 6, 'batch/listBatch', '', 0, 'Active', 0),
	(50, 'Upload Marks Excel(UG)', 32, 'excelupload/uploadUgMarksExcel', '', 0, 'Active', 0),
	(51, 'Manage Attendance', 0, NULL, 'fa fa-adn', 2, 'Active', 1),
	(52, 'Mark Attendance', 51, 'attendance/addAttendance', '', 1, 'Active', 0),
	(53, 'Student Dashboard', 0, NULL, 'fa fa-user-circle', 2, 'Active', 0),
	(54, 'Profile', 53, 'profile/userProfile', '', 1, 'Active', 0),
	(55, 'Process', 53, 'process/viewProcess', '', 0, 'Inactive', 0),
	(56, 'Report', 53, 'process/viewReport', '', 0, 'Inactive', 0),
	(57, 'Manage Message', 0, 'fa-envelope', '', 6, 'Active', 1),
	(58, 'Send Sms', 57, 'message/sendSms', '', 0, 'Active', 0),
	(59, 'Audit Trail', 0, '', 'fa fa-user', 10, 'Active', 1),
	(60, 'Payment History', 59, 'audit/paymentHistory', '', 0, 'Active', 0),
	(61, 'Sended Message', 57, 'message/listMessages', '', 0, 'Active', 0),
	(62, 'Roles', 6, 'rolemaster/listRole', '', 0, 'Active', 0),
	(63, 'Fee Due Alert', 57, 'message/feeAlert', '', 0, 'Active', 0),
	(64, 'Allocate Invigilator', 22, 'timetable/allocateInvigilator', '', 0, 'Active', 0),
	(65, 'FeedBack Form', 53, 'process/feedbackForm', '', 10, 'Active', 0),
	(66, 'Apply For Duplicate Certificate', 89, 'process/viewProcess#duplicate_certificate', '', 6, 'Active', 0),
	(67, 'Apply For Re-Evaluation', 89, 'process/viewProcess#re-evaluation', '', 6, 'Active', 0),
	(68, 'My Payment Details', 89, 'process/myPaymentDetails', '', 9, 'Active', 0),
	(69, 'View Marks', 88, 'process/viewMarks', '', 3, 'Active', 0),
	(70, 'View Mark Sheet', 88, 'process/viewMarkSheet', '', 4, 'Active', 0),
	(71, 'View Attendance', 87, 'process/viewAttendance', '', 2, 'Active', 0),
	(72, 'Hall Ticket', 89, 'process/viewHallTicket', '', 4, 'Active', 0),
	(73, 'Consolidated Certificate', 26, 'result/consolidatedCertificate', '', 0, 'Active', 0),
	(74, 'Exam Fees', 89, 'process/viewProcess#exam_fees', '', 5, 'Active', 0),
	(75, 'Year Wise consolidated', 89, 'process/viewProcess#year_wise_marksheet', '', 8, 'Active', 0),
	(76, 'Overall Consolidated', 89, 'process/viewProcess#consolidate', '', 8, 'Active', 0),
	(77, 'Transcript', 89, 'process/viewProcess#transcript', '', 8, 'Active', 0),
	(78, 'Manage Holidays', 51, 'attendance/manageholidays', '', 2, 'Active', 0),
	(79, 'Holidays List', 51, 'attendance/holidaylist', '', 3, 'Active', 0),
	(81, 'Manage Feedback', 0, 'fa-envelope', '', 5, 'Active', 1),
	(82, 'Feedback Result', 81, 'feedback/results', '', 2, 'Active', 0),
	(83, 'Feedback Chart', 81, 'feedback/chart', '', 3, 'Active', 0),
	(84, 'Add Feedback', 81, 'feedback/add', '', 1, 'Active', 0),
	(85, 'Login History', 59, 'audit/loginHistory', '', 0, 'Active', 0),
	(86, 'SMS History', 59, 'audit/smsHistory', '', 0, 'Active', 0),
	(87, 'Attendance', 0, NULL, 'fa fa-user-circle', 3, 'Active', 0),
	(88, 'Results', 0, NULL, 'fa fa-user-circle', 9, 'Active', 0),
	(89, 'Payments', 0, NULL, 'fa fa-user-circle', 8, 'Active', 0),
	(90, 'Class Room', 6, 'master/listclassroom', '', 0, 'Active', 0),
	(91, 'Exam Slot', 6, 'master/listexam_slot', '', 0, 'Active', 0),
	(92, 'Attendance Time Table', 51, 'attendance/manage_timetable', '', 2, 'Active', 0),
	(93, 'Profile', 1, 'profile/userProfile', '', 1, 'Active', 0),
	(94, 'Assign Course To Teacher', 51, 'attendance/assign_course_to_teacher', '', 2, 'Active', 0),
	(95, 'Student Wise Attendance', 51, 'attendance/studentwise_attendance', ' ', 3, 'Active', 0),
	(96, 'Course Subject Groups', 6, 'course/listCourseSubjectGroup', '', 0, 'Active', 0),
	(97, 'Student Course Assignment List', 18, 'course/studentCourseAssignmentList', '', 4, 'Active', 0),
	(98, 'Course Group Wise Report', 36, 'grade/courseGroupWiseReport', '', 0, 'Active', 0),
	(99, 'Revaluation Course Assignment', 18, 'course/revaluationCourseAssignmentList', '', 5, 'Inactive', 0),
	(100, 'List Teachers', 3, 'admin/listTeacher', '', 5, 'Active', 0),
	(101, 'List Students', 3, 'admin/listStudent', '', 5, 'Active', 0),
	(102, 'Condonation of shortage', 0, NULL, 'fa fa-calendar', 7, 'Active', 1),
	(103, 'Deflicit Mark List', 102, 'condonation/deflicit_mark', ' ', 1, 'Active', 0),
	(104, 'Deflicit Approval', 102, 'condonation/deflicit_approval', ' ', 2, 'Active', 0),
	(105, 'Register Students', 3, 'admin/registerStudent', '', 5, 'Active', 0);
/*!40000 ALTER TABLE `tbladminmenu` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.tblassignrole
DROP TABLE IF EXISTS `tblassignrole`;
CREATE TABLE IF NOT EXISTS `tblassignrole` (
  `assign_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) NOT NULL DEFAULT '0',
  `role_id` int(11) DEFAULT NULL,
  `main_menu` int(11) NOT NULL,
  `sub_menu` int(11) NOT NULL,
  `m_action` varchar(255) DEFAULT NULL COMMENT 'Add,View,Delete,Edit,Active',
  `r_status` int(11) NOT NULL DEFAULT '1',
  `r_createon` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`assign_id`)
) ENGINE=InnoDB AUTO_INCREMENT=309 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.tblassignrole: ~304 rows (approximately)
/*!40000 ALTER TABLE `tblassignrole` DISABLE KEYS */;
INSERT INTO `tblassignrole` (`assign_id`, `emp_id`, `role_id`, `main_menu`, `sub_menu`, `m_action`, `r_status`, `r_createon`) VALUES
	(2, 547, 4, 3, 4, NULL, 1, '2018-09-12 14:14:20'),
	(3, 547, 4, 3, 5, NULL, 1, '2018-09-12 14:14:20'),
	(4, 547, 4, 3, 35, NULL, 1, '2018-09-12 14:14:20'),
	(5, 547, 4, 3, 39, NULL, 1, '2018-09-12 14:14:20'),
	(6, 547, 4, 3, 40, NULL, 1, '2018-09-12 14:14:21'),
	(7, 547, 4, 26, 27, NULL, 1, '2018-09-12 15:21:49'),
	(8, 547, 4, 26, 42, NULL, 1, '2018-09-12 15:21:49'),
	(9, 547, 4, 26, 44, NULL, 1, '2018-09-12 15:21:49'),
	(10, 547, 4, 36, 37, NULL, 1, '2018-09-12 15:21:49'),
	(11, 567, 4, 32, 33, NULL, 1, '2018-10-11 14:03:20'),
	(12, 567, 4, 32, 34, NULL, 1, '2018-10-11 14:03:20'),
	(13, 567, 4, 32, 41, NULL, 1, '2018-10-11 14:03:20'),
	(14, 567, 4, 32, 46, NULL, 1, '2018-10-11 14:03:20'),
	(15, 567, 4, 32, 48, NULL, 1, '2018-10-11 14:03:20'),
	(16, 568, 4, 32, 33, NULL, 1, '2018-10-12 11:30:31'),
	(17, 568, 4, 32, 34, NULL, 1, '2018-10-12 11:30:31'),
	(18, 568, 4, 32, 41, NULL, 1, '2018-10-12 11:30:31'),
	(19, 568, 4, 32, 46, NULL, 1, '2018-10-12 11:30:31'),
	(20, 568, 4, 32, 48, NULL, 1, '2018-10-12 11:30:31'),
	(21, 567, 4, 1, 47, NULL, 1, '2018-10-16 15:08:00'),
	(22, 567, 4, 18, 19, NULL, 1, '2018-10-16 15:08:00'),
	(23, 567, 4, 18, 20, NULL, 1, '2018-10-16 15:08:00'),
	(24, 567, 4, 18, 21, NULL, 1, '2018-10-16 15:08:00'),
	(25, 567, 4, 18, 45, NULL, 1, '2018-10-16 15:08:00'),
	(26, 567, 4, 26, 27, NULL, 1, '2018-10-16 15:08:00'),
	(27, 567, 4, 26, 42, NULL, 1, '2018-10-16 15:08:01'),
	(28, 567, 4, 26, 44, NULL, 1, '2018-10-16 15:08:01'),
	(29, 567, 4, 32, 50, NULL, 1, '2018-10-18 12:20:47'),
	(30, 569, 4, 1, 47, NULL, 1, '2018-10-20 10:32:38'),
	(31, 569, 4, 3, 4, NULL, 1, '2018-10-20 10:32:38'),
	(32, 569, 4, 3, 5, NULL, 1, '2018-10-20 10:32:38'),
	(33, 569, 4, 3, 35, NULL, 1, '2018-10-20 10:32:38'),
	(34, 569, 4, 3, 39, NULL, 1, '2018-10-20 10:32:38'),
	(35, 569, 4, 3, 40, NULL, 1, '2018-10-20 10:32:38'),
	(36, 569, 4, 6, 7, NULL, 1, '2018-10-20 10:32:38'),
	(37, 569, 4, 6, 9, NULL, 1, '2018-10-20 10:32:39'),
	(38, 569, 4, 6, 11, NULL, 1, '2018-10-20 10:32:39'),
	(39, 569, 4, 6, 13, NULL, 1, '2018-10-20 10:32:39'),
	(40, 569, 4, 6, 14, NULL, 1, '2018-10-20 10:32:39'),
	(41, 569, 4, 6, 15, NULL, 1, '2018-10-20 10:32:39'),
	(42, 569, 4, 6, 16, NULL, 1, '2018-10-20 10:32:39'),
	(43, 569, 4, 6, 17, NULL, 1, '2018-10-20 10:32:39'),
	(44, 569, 4, 6, 49, NULL, 1, '2018-10-20 10:32:39'),
	(45, 569, 4, 18, 19, NULL, 1, '2018-10-20 10:32:39'),
	(46, 569, 4, 18, 20, NULL, 1, '2018-10-20 10:32:39'),
	(47, 569, 4, 18, 21, NULL, 1, '2018-10-20 10:32:39'),
	(48, 569, 4, 18, 45, NULL, 1, '2018-10-20 10:32:39'),
	(49, 569, 4, 22, 24, NULL, 1, '2018-10-20 10:32:39'),
	(50, 569, 4, 26, 27, NULL, 1, '2018-10-20 10:32:39'),
	(51, 569, 4, 26, 42, NULL, 1, '2018-10-20 10:32:39'),
	(52, 569, 4, 26, 44, NULL, 1, '2018-10-20 10:32:39'),
	(53, 569, 4, 28, 29, NULL, 1, '2018-10-20 10:32:39'),
	(54, 569, 4, 30, 31, NULL, 1, '2018-10-20 10:32:39'),
	(55, 569, 4, 32, 33, NULL, 1, '2018-10-20 10:32:39'),
	(56, 569, 4, 32, 34, NULL, 1, '2018-10-20 10:32:39'),
	(57, 569, 4, 32, 41, NULL, 1, '2018-10-20 10:32:39'),
	(58, 569, 4, 32, 46, NULL, 1, '2018-10-20 10:32:39'),
	(59, 569, 4, 32, 48, NULL, 1, '2018-10-20 10:32:39'),
	(60, 569, 4, 32, 50, NULL, 1, '2018-10-20 10:32:39'),
	(61, 569, 4, 36, 37, NULL, 1, '2018-10-20 10:32:39'),
	(62, 570, 4, 1, 47, NULL, 1, '2018-10-20 12:22:28'),
	(63, 570, 4, 18, 19, NULL, 1, '2018-10-20 12:22:28'),
	(64, 570, 4, 18, 20, NULL, 1, '2018-10-20 12:22:28'),
	(65, 570, 4, 18, 21, NULL, 1, '2018-10-20 12:22:28'),
	(66, 570, 4, 18, 45, NULL, 1, '2018-10-20 12:22:28'),
	(67, 570, 4, 30, 31, NULL, 1, '2018-10-20 12:22:28'),
	(68, 570, 4, 32, 33, NULL, 1, '2018-10-20 12:22:28'),
	(69, 570, 4, 32, 34, NULL, 1, '2018-10-20 12:22:28'),
	(70, 570, 4, 32, 41, NULL, 1, '2018-10-20 12:22:28'),
	(71, 570, 4, 32, 46, NULL, 1, '2018-10-20 12:22:28'),
	(72, 570, 4, 32, 48, NULL, 1, '2018-10-20 12:22:28'),
	(73, 570, 4, 32, 50, NULL, 1, '2018-10-20 12:22:28'),
	(74, 570, 4, 36, 37, NULL, 1, '2018-10-20 12:22:28'),
	(75, 98, 1, 53, 54, NULL, 1, '2018-11-12 09:12:30'),
	(76, 98, 1, 53, 55, NULL, 1, '2018-11-12 09:12:30'),
	(77, 98, 1, 53, 56, NULL, 1, '2018-11-12 09:12:30'),
	(78, 571, 7, 1, 47, NULL, 1, '2018-11-19 13:59:38'),
	(79, 574, 8, 1, 47, NULL, 1, '2018-11-23 07:16:26'),
	(80, 574, 8, 51, 52, NULL, 1, '2018-11-23 07:16:26'),
	(81, 571, 7, 22, 24, NULL, 1, '2018-11-23 08:45:45'),
	(82, 575, 2, 1, 47, NULL, 1, '2018-11-26 07:07:49'),
	(83, 575, 2, 22, 24, NULL, 1, '2018-11-26 07:07:49'),
	(84, 98, 1, 53, 65, NULL, 1, '2018-11-12 09:12:30'),
	(85, 98, 1, 53, 66, NULL, 1, '2018-11-12 09:12:30'),
	(86, 98, 1, 53, 67, NULL, 1, '2018-11-12 09:12:30'),
	(87, 98, 1, 53, 68, NULL, 1, '2018-11-12 09:12:30'),
	(88, 98, 1, 53, 69, NULL, 1, '2018-11-12 09:12:30'),
	(89, 98, 1, 53, 70, NULL, 1, '2018-11-12 09:12:30'),
	(90, 98, 1, 53, 71, NULL, 1, '2018-11-12 09:12:30'),
	(91, 98, 1, 53, 72, NULL, 1, '2018-11-12 09:12:30'),
	(92, 580, 1, 53, 54, NULL, 1, '2018-12-10 11:39:12'),
	(93, 580, 1, 53, 65, NULL, 1, '2018-12-10 11:39:12'),
	(94, 580, 1, 53, 66, NULL, 1, '2018-12-10 11:39:13'),
	(95, 580, 1, 53, 67, NULL, 1, '2018-12-10 11:39:13'),
	(96, 580, 1, 53, 68, NULL, 1, '2018-12-10 11:39:13'),
	(97, 580, 1, 53, 69, NULL, 1, '2018-12-10 11:39:13'),
	(98, 580, 1, 53, 70, NULL, 1, '2018-12-10 11:39:13'),
	(99, 580, 1, 53, 71, NULL, 1, '2018-12-10 11:39:13'),
	(100, 580, 1, 53, 72, NULL, 1, '2018-12-10 11:39:13'),
	(101, 98, 1, 53, 74, NULL, 1, '2018-12-13 10:52:09'),
	(102, 98, 1, 53, 75, NULL, 1, '2018-12-13 10:52:09'),
	(103, 98, 1, 53, 76, NULL, 1, '2018-12-13 10:52:09'),
	(104, 99, 6, 53, 54, NULL, 1, '2018-12-14 10:11:25'),
	(105, 99, 6, 53, 66, NULL, 1, '2018-12-14 10:11:25'),
	(106, 99, 6, 53, 68, NULL, 1, '2018-12-14 10:11:25'),
	(107, 99, 6, 53, 70, NULL, 1, '2018-12-14 10:11:25'),
	(108, 99, 6, 53, 75, NULL, 1, '2018-12-14 10:11:25'),
	(109, 99, 6, 53, 76, NULL, 1, '2018-12-14 10:11:25'),
	(110, 98, 1, 53, 77, NULL, 1, '2018-12-20 16:37:50'),
	(111, 575, 2, 51, 52, NULL, 1, '2018-12-22 11:49:29'),
	(112, 575, 2, 51, 79, NULL, 1, '2018-12-24 17:27:30'),
	(114, 98, 1, 87, 71, NULL, 1, '2019-01-05 14:22:16'),
	(115, 98, 1, 88, 69, NULL, 1, '2019-01-05 14:24:38'),
	(116, 98, 1, 88, 70, NULL, 1, '2019-01-05 14:24:38'),
	(117, 98, 1, 89, 66, NULL, 1, '2019-01-05 14:27:50'),
	(118, 98, 1, 89, 67, NULL, 1, '2019-01-05 14:27:50'),
	(119, 98, 1, 89, 68, NULL, 1, '2019-01-05 14:27:50'),
	(120, 98, 1, 89, 72, NULL, 1, '2019-01-05 14:27:50'),
	(121, 584, 5, 53, 54, NULL, 1, '2019-01-05 19:26:32'),
	(122, 584, 5, 53, 65, NULL, 1, '2019-01-05 19:26:32'),
	(123, 584, 5, 87, 71, NULL, 1, '2019-01-05 19:26:32'),
	(124, 584, 5, 88, 69, NULL, 1, '2019-01-05 19:26:33'),
	(125, 584, 5, 88, 70, NULL, 1, '2019-01-05 19:26:33'),
	(126, 584, 5, 89, 66, NULL, 1, '2019-01-05 19:26:33'),
	(127, 584, 5, 89, 67, NULL, 1, '2019-01-05 19:26:33'),
	(128, 584, 5, 89, 68, NULL, 1, '2019-01-05 19:26:33'),
	(129, 584, 5, 89, 72, NULL, 1, '2019-01-05 19:26:33'),
	(130, 584, 5, 89, 74, NULL, 1, '2019-01-05 19:26:33'),
	(131, 584, 5, 89, 75, NULL, 1, '2019-01-05 19:26:33'),
	(132, 584, 5, 89, 76, NULL, 1, '2019-01-05 19:26:33'),
	(133, 584, 5, 89, 77, NULL, 1, '2019-01-05 19:26:33'),
	(134, 580, 1, 53, 54, NULL, 1, '2019-01-05 19:51:19'),
	(135, 580, 1, 53, 65, NULL, 1, '2019-01-05 19:51:19'),
	(136, 580, 1, 87, 71, NULL, 1, '2019-01-05 19:51:19'),
	(137, 580, 1, 88, 69, NULL, 1, '2019-01-05 19:51:19'),
	(138, 580, 1, 88, 70, NULL, 1, '2019-01-05 19:51:19'),
	(139, 580, 1, 89, 66, NULL, 1, '2019-01-05 19:51:19'),
	(140, 580, 1, 89, 67, NULL, 1, '2019-01-05 19:51:19'),
	(141, 580, 1, 89, 68, NULL, 1, '2019-01-05 19:51:20'),
	(142, 580, 1, 89, 72, NULL, 1, '2019-01-05 19:51:20'),
	(143, 580, 1, 89, 74, NULL, 1, '2019-01-05 19:51:20'),
	(144, 580, 1, 89, 75, NULL, 1, '2019-01-05 19:51:20'),
	(145, 580, 1, 89, 76, NULL, 1, '2019-01-05 19:51:20'),
	(146, 580, 1, 89, 77, NULL, 1, '2019-01-05 19:51:20'),
	(147, 580, 1, 53, 54, NULL, 1, '2019-01-05 19:54:11'),
	(148, 580, 1, 53, 65, NULL, 1, '2019-01-05 19:54:11'),
	(149, 580, 1, 87, 71, NULL, 1, '2019-01-05 19:54:11'),
	(150, 580, 1, 88, 69, NULL, 1, '2019-01-05 19:54:11'),
	(151, 580, 1, 88, 70, NULL, 1, '2019-01-05 19:54:12'),
	(152, 580, 1, 89, 66, NULL, 1, '2019-01-05 19:54:12'),
	(153, 580, 1, 89, 67, NULL, 1, '2019-01-05 19:54:12'),
	(154, 580, 1, 89, 68, NULL, 1, '2019-01-05 19:54:12'),
	(155, 580, 1, 89, 72, NULL, 1, '2019-01-05 19:54:12'),
	(156, 580, 1, 89, 74, NULL, 1, '2019-01-05 19:54:12'),
	(157, 580, 1, 89, 75, NULL, 1, '2019-01-05 19:54:12'),
	(158, 580, 1, 89, 76, NULL, 1, '2019-01-05 19:54:12'),
	(159, 580, 1, 89, 77, NULL, 1, '2019-01-05 19:54:12'),
	(160, 583, 1, 53, 54, NULL, 1, '2019-01-05 19:57:24'),
	(161, 583, 1, 53, 65, NULL, 1, '2019-01-05 19:57:24'),
	(162, 583, 1, 87, 71, NULL, 1, '2019-01-05 19:57:24'),
	(163, 583, 1, 88, 69, NULL, 1, '2019-01-05 19:57:24'),
	(164, 583, 1, 88, 70, NULL, 1, '2019-01-05 19:57:24'),
	(165, 583, 1, 89, 66, NULL, 1, '2019-01-05 19:57:24'),
	(166, 583, 1, 89, 67, NULL, 1, '2019-01-05 19:57:24'),
	(167, 583, 1, 89, 68, NULL, 1, '2019-01-05 19:57:25'),
	(168, 583, 1, 89, 72, NULL, 1, '2019-01-05 19:57:25'),
	(169, 583, 1, 89, 74, NULL, 1, '2019-01-05 19:57:25'),
	(170, 583, 1, 89, 75, NULL, 1, '2019-01-05 19:57:25'),
	(171, 583, 1, 89, 76, NULL, 1, '2019-01-05 19:57:25'),
	(172, 583, 1, 89, 77, NULL, 1, '2019-01-05 19:57:25'),
	(173, 98, 1, 22, 24, NULL, 1, '2019-01-08 09:11:06'),
	(174, 572, 2, 22, 24, NULL, 1, '2019-01-08 09:12:54'),
	(175, 572, 2, 1, 93, NULL, 1, '2019-01-17 19:30:09'),
	(176, 572, 2, 51, 52, NULL, 1, '2019-01-17 19:30:09'),
	(177, 572, 2, 51, 79, NULL, 1, '2019-01-17 19:30:09'),
	(178, 574, 8, 6, 7, NULL, 1, '2019-01-22 11:07:44'),
	(179, 574, 8, 6, 9, NULL, 1, '2019-01-22 11:07:44'),
	(180, 574, 8, 6, 11, NULL, 1, '2019-01-22 11:07:44'),
	(181, 574, 8, 6, 13, NULL, 1, '2019-01-22 11:07:44'),
	(182, 574, 8, 6, 14, NULL, 1, '2019-01-22 11:07:44'),
	(183, 574, 8, 6, 15, NULL, 1, '2019-01-22 11:07:44'),
	(184, 574, 8, 6, 16, NULL, 1, '2019-01-22 11:07:44'),
	(185, 574, 8, 6, 17, NULL, 1, '2019-01-22 11:07:44'),
	(186, 574, 8, 6, 49, NULL, 1, '2019-01-22 11:07:44'),
	(187, 574, 8, 6, 62, NULL, 1, '2019-01-22 11:07:44'),
	(188, 574, 8, 6, 90, NULL, 1, '2019-01-22 11:07:44'),
	(189, 574, 8, 6, 91, NULL, 1, '2019-01-22 11:07:44'),
	(190, 574, 8, 18, 19, NULL, 1, '2019-01-22 11:07:44'),
	(191, 574, 8, 18, 20, NULL, 1, '2019-01-22 11:07:44'),
	(192, 574, 8, 18, 21, NULL, 1, '2019-01-22 11:07:44'),
	(193, 574, 8, 18, 45, NULL, 1, '2019-01-22 11:07:44'),
	(194, 574, 8, 22, 24, NULL, 1, '2019-01-22 11:07:44'),
	(195, 574, 8, 22, 64, NULL, 1, '2019-01-22 11:07:44'),
	(196, 574, 8, 26, 27, NULL, 1, '2019-01-22 11:07:44'),
	(197, 574, 8, 26, 42, NULL, 1, '2019-01-22 11:07:44'),
	(198, 574, 8, 26, 44, NULL, 1, '2019-01-22 11:07:44'),
	(199, 574, 8, 26, 73, NULL, 1, '2019-01-22 11:07:44'),
	(200, 574, 8, 30, 31, NULL, 1, '2019-01-22 11:07:44'),
	(201, 574, 8, 32, 33, NULL, 1, '2019-01-22 11:07:44'),
	(202, 574, 8, 32, 50, NULL, 1, '2019-01-22 11:07:44'),
	(203, 574, 8, 36, 37, NULL, 1, '2019-01-22 11:07:44'),
	(204, 574, 8, 51, 52, NULL, 1, '2019-01-22 11:07:44'),
	(205, 574, 8, 51, 78, NULL, 1, '2019-01-22 11:07:44'),
	(206, 574, 8, 51, 79, NULL, 1, '2019-01-22 11:07:44'),
	(207, 574, 8, 51, 92, NULL, 1, '2019-01-22 11:07:44'),
	(208, 574, 8, 57, 58, NULL, 1, '2019-01-22 11:07:44'),
	(209, 574, 8, 57, 61, NULL, 1, '2019-01-22 11:07:44'),
	(210, 574, 8, 57, 63, NULL, 1, '2019-01-22 11:07:44'),
	(211, 574, 8, 59, 60, NULL, 1, '2019-01-22 11:07:44'),
	(212, 574, 8, 59, 85, NULL, 1, '2019-01-22 11:07:44'),
	(213, 574, 8, 59, 86, NULL, 1, '2019-01-22 11:07:44'),
	(214, 574, 8, 81, 82, NULL, 1, '2019-01-22 11:07:44'),
	(215, 574, 8, 81, 83, NULL, 1, '2019-01-22 11:07:44'),
	(216, 574, 8, 81, 84, NULL, 1, '2019-01-22 11:07:44'),
	(217, 574, 8, 88, 69, NULL, 1, '2019-01-22 11:07:44'),
	(218, 574, 8, 88, 70, NULL, 1, '2019-01-22 11:07:44'),
	(219, 571, 7, 22, 24, NULL, 1, '2019-01-22 11:12:46'),
	(220, 571, 7, 26, 27, NULL, 1, '2019-01-22 11:12:46'),
	(221, 571, 7, 32, 33, NULL, 1, '2019-01-22 11:12:46'),
	(222, 571, 7, 36, 37, NULL, 1, '2019-01-22 11:12:46'),
	(224, 571, 7, 51, 78, NULL, 1, '2019-01-22 11:14:05'),
	(225, 571, 7, 57, 58, NULL, 1, '2019-01-22 11:15:14'),
	(226, 571, 7, 57, 61, NULL, 1, '2019-01-22 11:15:14'),
	(227, 571, 7, 57, 63, NULL, 1, '2019-01-22 11:15:14'),
	(228, 572, 2, 22, 24, NULL, 1, '2019-01-22 11:28:50'),
	(229, 572, 2, 26, 27, NULL, 1, '2019-01-22 11:28:50'),
	(230, 572, 2, 32, 33, NULL, 1, '2019-01-22 11:28:50'),
	(231, 572, 2, 32, 50, NULL, 1, '2019-01-22 11:28:50'),
	(233, 743, 9, 30, 31, NULL, 1, '2019-01-22 23:04:22'),
	(234, 554, 5, 87, 71, NULL, 1, '2019-01-23 15:38:09'),
	(235, 554, 5, 22, 24, NULL, 1, '2019-01-23 15:39:51'),
	(236, 554, 5, 88, 69, NULL, 1, '2019-01-23 15:39:51'),
	(237, 554, 5, 88, 70, NULL, 1, '2019-01-23 15:39:51'),
	(238, 554, 5, 89, 66, NULL, 1, '2019-01-23 15:39:51'),
	(239, 554, 5, 89, 67, NULL, 1, '2019-01-23 15:39:51'),
	(240, 554, 5, 89, 68, NULL, 1, '2019-01-23 15:39:51'),
	(241, 554, 5, 89, 72, NULL, 1, '2019-01-23 15:39:51'),
	(242, 554, 5, 89, 74, NULL, 1, '2019-01-23 15:39:51'),
	(243, 554, 5, 89, 75, NULL, 1, '2019-01-23 15:39:51'),
	(244, 554, 5, 89, 76, NULL, 1, '2019-01-23 15:39:51'),
	(245, 554, 5, 89, 77, NULL, 1, '2019-01-23 15:39:51'),
	(246, 744, 9, 18, 19, NULL, 1, '2019-01-23 15:43:02'),
	(247, 744, 9, 18, 20, NULL, 1, '2019-01-23 15:43:02'),
	(248, 744, 9, 18, 21, NULL, 1, '2019-01-23 15:43:02'),
	(249, 744, 9, 18, 45, NULL, 1, '2019-01-23 15:43:02'),
	(250, 744, 9, 22, 24, NULL, 1, '2019-01-23 15:43:02'),
	(251, 744, 9, 22, 64, NULL, 1, '2019-01-23 15:43:02'),
	(252, 744, 9, 32, 33, NULL, 1, '2019-01-23 15:43:02'),
	(253, 744, 9, 32, 50, NULL, 1, '2019-01-23 15:43:02'),
	(254, 744, 9, 57, 58, NULL, 1, '2019-01-23 15:43:02'),
	(255, 744, 9, 57, 61, NULL, 1, '2019-01-23 15:43:02'),
	(256, 744, 9, 57, 63, NULL, 1, '2019-01-23 15:43:02'),
	(257, 744, 9, 59, 60, NULL, 1, '2019-01-23 15:43:02'),
	(258, 744, 9, 59, 85, NULL, 1, '2019-01-23 15:43:02'),
	(259, 744, 9, 59, 86, NULL, 1, '2019-01-23 15:43:02'),
	(260, 745, 10, 3, 5, NULL, 1, '2019-01-23 15:46:29'),
	(261, 745, 10, 22, 24, NULL, 1, '2019-01-23 15:46:29'),
	(262, 745, 10, 26, 27, NULL, 1, '2019-01-23 15:46:29'),
	(263, 745, 10, 26, 42, NULL, 1, '2019-01-23 15:46:29'),
	(264, 745, 10, 26, 44, NULL, 1, '2019-01-23 15:46:29'),
	(265, 745, 10, 26, 73, NULL, 1, '2019-01-23 15:46:29'),
	(266, 747, 12, 6, 90, NULL, 1, '2019-01-23 15:49:01'),
	(267, 747, 12, 6, 91, NULL, 1, '2019-01-23 15:49:01'),
	(268, 747, 12, 22, 24, NULL, 1, '2019-01-23 15:49:01'),
	(269, 747, 12, 22, 64, NULL, 1, '2019-01-23 15:49:01'),
	(270, 747, 12, 26, 73, NULL, 1, '2019-01-23 15:49:01'),
	(271, 571, 7, 51, 52, NULL, 1, '2019-01-24 11:07:06'),
	(272, 571, 7, 51, 78, NULL, 1, '2019-01-24 11:07:06'),
	(273, 571, 7, 51, 79, NULL, 1, '2019-01-24 11:07:06'),
	(274, 571, 7, 51, 92, NULL, 1, '2019-01-24 11:07:06'),
	(275, 571, 7, 51, 94, NULL, 1, '2019-01-24 11:07:06'),
	(276, 571, 7, 51, 95, NULL, 1, '2019-01-24 11:07:06'),
	(277, 747, 12, 51, 52, NULL, 1, '2019-01-24 11:07:36'),
	(278, 747, 12, 51, 79, NULL, 1, '2019-01-24 11:07:36'),
	(279, 747, 12, 51, 92, NULL, 1, '2019-01-24 11:07:36'),
	(280, 747, 12, 51, 94, NULL, 1, '2019-01-24 11:07:36'),
	(281, 747, 12, 51, 95, NULL, 1, '2019-01-24 11:07:36'),
	(282, 572, 2, 51, 92, NULL, 1, '2019-01-24 14:40:50'),
	(283, 572, 2, 51, 95, NULL, 1, '2019-01-29 11:05:47'),
	(284, 744, 9, 6, 7, NULL, 1, '2019-02-06 14:49:04'),
	(285, 744, 9, 6, 9, NULL, 1, '2019-02-06 14:49:04'),
	(286, 744, 9, 6, 11, NULL, 1, '2019-02-06 14:49:04'),
	(287, 744, 9, 6, 13, NULL, 1, '2019-02-06 14:49:04'),
	(288, 744, 9, 6, 14, NULL, 1, '2019-02-06 14:49:04'),
	(289, 744, 9, 6, 15, NULL, 1, '2019-02-06 14:49:04'),
	(290, 744, 9, 6, 16, NULL, 1, '2019-02-06 14:49:04'),
	(291, 744, 9, 6, 17, NULL, 1, '2019-02-06 14:49:04'),
	(292, 744, 9, 6, 49, NULL, 1, '2019-02-06 14:49:04'),
	(293, 744, 9, 6, 62, NULL, 1, '2019-02-06 14:49:04'),
	(294, 744, 9, 6, 90, NULL, 1, '2019-02-06 14:49:04'),
	(295, 744, 9, 6, 91, NULL, 1, '2019-02-06 14:49:04'),
	(296, 744, 9, 6, 96, NULL, 1, '2019-02-06 14:49:04'),
	(297, 744, 9, 26, 27, NULL, 1, '2019-02-06 14:49:04'),
	(298, 744, 9, 26, 44, NULL, 1, '2019-02-06 14:49:04'),
	(299, 744, 9, 26, 73, NULL, 1, '2019-02-06 14:49:04'),
	(300, 744, 9, 30, 31, NULL, 1, '2019-02-06 14:49:04'),
	(301, 744, 9, 36, 37, NULL, 1, '2019-02-06 14:49:04'),
	(302, 744, 9, 36, 98, NULL, 1, '2019-02-06 14:49:04'),
	(303, 744, 9, 51, 79, NULL, 1, '2019-02-06 14:49:04'),
	(304, 744, 9, 51, 92, NULL, 1, '2019-02-06 14:49:04'),
	(305, 744, 9, 51, 94, NULL, 1, '2019-02-06 14:49:04'),
	(306, 744, 9, 88, 69, NULL, 1, '2019-02-06 14:49:04'),
	(307, 744, 9, 88, 70, NULL, 1, '2019-02-06 14:49:04'),
	(308, 747, 12, 1, 93, NULL, 1, '2019-02-06 17:34:20');
/*!40000 ALTER TABLE `tblassignrole` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.tblpage
DROP TABLE IF EXISTS `tblpage`;
CREATE TABLE IF NOT EXISTS `tblpage` (
  `page_id` int(11) NOT NULL AUTO_INCREMENT,
  `page_name` varchar(255) NOT NULL,
  `page_link` varchar(255) NOT NULL,
  PRIMARY KEY (`page_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.tblpage: ~15 rows (approximately)
/*!40000 ALTER TABLE `tblpage` DISABLE KEYS */;
INSERT INTO `tblpage` (`page_id`, `page_name`, `page_link`) VALUES
	(1, 'Add User', 'admin/addUser'),
	(2, 'User List ', 'admin/listUser'),
	(3, 'Add Permission', 'permissions/addPermission'),
	(4, 'Discipline List', 'discipline/viewDiscipline'),
	(5, 'Add Discipline', 'discipline/addDiscipline'),
	(6, 'Program List', 'program/listProgram'),
	(7, 'Add Program', 'program/addProgram'),
	(8, 'View Degree', 'master/listDegree'),
	(9, 'Add Degree', 'master/addDegree'),
	(10, 'List Syllabus Year', 'master/listSyllabusYear'),
	(11, 'Add Syllabus Year', 'master/addSyllabusYear'),
	(12, 'Semester List', 'semester/listSemester'),
	(13, 'Add Semester', 'semester/addSemester'),
	(14, 'Course List', 'course/listCourseGroup'),
	(15, 'Add Course Group', 'course/addCourseGroup');
/*!40000 ALTER TABLE `tblpage` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.tbl_course_assignment
DROP TABLE IF EXISTS `tbl_course_assignment`;
CREATE TABLE IF NOT EXISTS `tbl_course_assignment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `program_id` int(11) NOT NULL,
  `campus_id` int(11) NOT NULL,
  `degree_id` int(11) NOT NULL,
  `semester_id` int(11) NOT NULL,
  `previous_semester_id` int(11) NOT NULL,
  `syllabus_year_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `start_date` varchar(255) DEFAULT NULL,
  `date_of_closure` varchar(500) DEFAULT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=128 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.tbl_course_assignment: 120 rows
/*!40000 ALTER TABLE `tbl_course_assignment` DISABLE KEYS */;
INSERT INTO `tbl_course_assignment` (`id`, `program_id`, `campus_id`, `degree_id`, `semester_id`, `previous_semester_id`, `syllabus_year_id`, `batch_id`, `course_id`, `start_date`, `date_of_closure`, `created_on`, `updated_on`, `status`) VALUES
	(1, 1, 1, 1, 1, 1, 1, 1, 1, '13-08-2018', '13-08-2018', '2018-08-06 13:59:47', NULL, 1),
	(2, 1, 1, 1, 1, 1, 1, 1, 2, '26-10-2018', '31-10-2018', '2018-08-06 13:59:47', NULL, 1),
	(3, 1, 1, 1, 1, 1, 1, 1, 3, NULL, NULL, '2018-08-06 13:59:47', NULL, 1),
	(4, 1, 1, 1, 1, 1, 1, 1, 4, NULL, NULL, '2018-08-06 13:59:47', NULL, 1),
	(5, 1, 1, 1, 1, 1, 1, 1, 5, NULL, NULL, '2018-08-06 13:59:47', NULL, 1),
	(6, 1, 1, 1, 1, 1, 1, 1, 6, NULL, NULL, '2018-08-06 13:59:47', NULL, 1),
	(7, 1, 5, 2, 2, 2, 1, 1, 7, '01-02-2019', '01-02-2019', '2018-08-21 15:19:51', NULL, 1),
	(8, 1, 5, 2, 2, 2, 1, 1, 8, NULL, NULL, '2018-08-21 15:19:51', NULL, 1),
	(9, 1, 5, 2, 2, 2, 1, 1, 9, NULL, NULL, '2018-08-21 15:19:51', NULL, 1),
	(10, 1, 5, 2, 2, 2, 1, 1, 10, NULL, NULL, '2018-08-21 15:19:51', NULL, 1);
	
/*!40000 ALTER TABLE `tbl_course_assignment` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.tbl_dummy
DROP TABLE IF EXISTS `tbl_dummy`;
CREATE TABLE IF NOT EXISTS `tbl_dummy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `college_id` int(11) DEFAULT NULL,
  `batch_id` int(11) DEFAULT NULL,
  `degree_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `exam_month` varchar(100) DEFAULT NULL,
  `dummy_value` varchar(100) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `status` tinyint(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1051 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.tbl_dummy: ~820 rows (approximately)
/*!40000 ALTER TABLE `tbl_dummy` DISABLE KEYS */;
INSERT INTO `tbl_dummy` (`id`, `college_id`, `batch_id`, `degree_id`, `student_id`, `exam_month`, `dummy_value`, `created_on`, `updated_on`, `status`) VALUES
	(1, 1, 1, 1, 98, 'Aug', '1261', '2018-08-07 12:56:09', NULL, NULL),
	(2, 1, 1, 1, 99, 'Aug', '1097', '2018-08-07 12:56:09', NULL, NULL),
	(3, 1, 1, 1, 100, 'Aug', '1109', '2018-08-07 12:56:09', NULL, NULL),
	(4, 1, 1, 1, 101, 'Aug', '1447', '2018-08-07 12:56:09', NULL, NULL),
	(5, 1, 1, 1, 102, 'Aug', '1106', '2018-08-07 12:56:09', NULL, NULL),
	(6, 1, 1, 1, 103, 'Aug', '1516', '2018-08-07 12:56:09', NULL, NULL),
	(7, 1, 1, 1, 104, 'Aug', '1132', '2018-08-07 12:56:09', NULL, NULL),
	(8, 1, 1, 1, 105, 'Aug', '1930', '2018-08-07 12:56:09', NULL, NULL),
	(9, 1, 1, 1, 106, 'Aug', '1772', '2018-08-07 12:56:09', NULL, NULL),
	(10, 1, 1, 1, 107, 'Aug', '1169', '2018-08-07 12:56:09', NULL, NULL);
/*!40000 ALTER TABLE `tbl_dummy` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.tbl_user_pending_updates
DROP TABLE IF EXISTS `tbl_user_pending_updates`;
CREATE TABLE IF NOT EXISTS `tbl_user_pending_updates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contact_number` varchar(100) DEFAULT NULL,
  `roll` varchar(100) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `batch` int(11) DEFAULT NULL,
  `campus` int(11) DEFAULT NULL,
  `degree` int(11) DEFAULT NULL,
  `course_type` int(11) DEFAULT NULL,
  `religion` int(11) DEFAULT NULL,
  `nationality` int(11) DEFAULT NULL,
  `zip_code` varchar(100) DEFAULT NULL,
  `country` int(11) DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `otp` char(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.tbl_user_pending_updates: 0 rows
/*!40000 ALTER TABLE `tbl_user_pending_updates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_user_pending_updates` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.time_tables
DROP TABLE IF EXISTS `time_tables`;
CREATE TABLE IF NOT EXISTS `time_tables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slots` int(11) NOT NULL DEFAULT '0',
  `exam_date_id` int(11) NOT NULL DEFAULT '0',
  `teacher_id` int(11) NOT NULL DEFAULT '0',
  `room_id` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(2) NOT NULL DEFAULT '0',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_on` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.time_tables: ~15 rows (approximately)
/*!40000 ALTER TABLE `time_tables` DISABLE KEYS */;
INSERT INTO `time_tables` (`id`, `slots`, `exam_date_id`, `teacher_id`, `room_id`, `status`, `created_on`, `updated_on`) VALUES
	(1, 2, 81, 572, 3, 0, '2020-01-08 08:48:33', '2019-01-27 12:56:09'),
	(2, 3, 82, 572, 2, 0, '2020-01-08 08:48:50', '2019-01-27 12:56:13'),
	(3, 3, 83, 572, 1, 0, '2020-01-08 08:56:12', '2019-01-27 12:56:17'),
	(4, 2, 84, 572, 1, 0, '2020-01-26 16:06:09', '2019-01-27 12:56:20'),
	(5, 3, 85, 572, 3, 0, '2020-01-26 16:06:19', '2019-01-27 12:56:24'),
	(6, 4, 86, 572, 3, 0, '2020-01-26 16:06:30', '2019-01-27 12:56:29'),
	(7, 3, 87, 572, 2, 0, '2020-01-26 16:06:45', '2019-01-27 12:56:39'),
	(8, 2, 88, 572, 1, 0, '2020-01-26 16:09:39', '2019-01-27 12:57:04'),
	(9, 2, 89, 572, 3, 0, '2020-01-26 16:09:46', '2019-01-27 12:57:07'),
	(10, 2, 90, 572, 1, 0, '2020-01-26 16:09:53', '2019-01-27 12:57:12'),
	(11, 2, 91, 572, 3, 0, '2020-01-26 16:10:03', '2019-01-27 12:57:15'),
	(12, 3, 92, 572, 3, 0, '2020-01-26 16:10:13', '2019-01-27 12:57:18'),
	(13, 3, 93, 572, 3, 0, '2020-01-26 16:10:22', '2019-01-27 12:57:22'),
	(14, 4, 94, 572, 4, 0, '2020-01-26 16:10:34', '2019-01-27 12:57:27'),
	(15, 2, 95, 572, 1, 0, '2020-01-27 12:54:55', '2019-01-27 12:57:30');
/*!40000 ALTER TABLE `time_tables` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_unique_id` varchar(150) DEFAULT NULL,
  `application_no` varchar(150) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `aadhaar_no` varchar(50) DEFAULT NULL,
  `caste` varchar(100) DEFAULT NULL,
  `community` varchar(100) DEFAULT NULL,
  `user_image` text,
  `contact_number` bigint(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `gender` varchar(25) DEFAULT NULL,
  `parents_student_id` int(11) DEFAULT NULL,
  `permission_status` enum('Yes','No') DEFAULT 'No',
  `subadmin_campus_id` tinyint(4) DEFAULT NULL,
  `upload_type` tinyint(4) DEFAULT NULL,
  `created_on` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_on` datetime DEFAULT CURRENT_TIMESTAMP,
  `last_login_time` varchar(255) DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=748 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.users: ~637 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `user_unique_id`, `application_no`, `role_id`, `username`, `password`, `first_name`, `last_name`, `aadhaar_no`, `caste`, `community`, `user_image`, `contact_number`, `email`, `dob`, `gender`, `parents_student_id`, `permission_status`, `subadmin_campus_id`, `upload_type`, `created_on`, `updated_on`, `last_login_time`, `status`) VALUES
	(1, '', NULL, 0, 'tamilarasiv1500@@gmail.com', 'tamil', 'Suresh Kumar R', 'Kumar', NULL, '0', NULL, 'BVN17001.jpg', 9898989898, 'tamilarasiv1500@gmail.com', '15-04-2000', 'Female', NULL, 'Yes', NULL, 1, '2019-02-14 22:51:06', '2018-09-07 10:32:34', '2019-02-16 17:28:30', 1),
	il.com', '22-01-2019', 'male', NULL, '', 0, 1, '2019-01-23 14:56:10', '2019-01-23 14:56:10', '2019-01-26 08:50:10', 1);
	
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.user_log
DROP TABLE IF EXISTS `user_log`;
CREATE TABLE IF NOT EXISTS `user_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `created_on` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `log_type` varchar(255) DEFAULT NULL,
  `ipaddress` varchar(255) DEFAULT NULL,
  `full_user_agent_string` varchar(255) DEFAULT NULL,
  `status` enum('Y','N') DEFAULT 'Y',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1143 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.user_log: ~1,132 rows (approximately)
/*!40000 ALTER TABLE `user_log` DISABLE KEYS */;
INSERT INTO `user_log` (`id`, `user_id`, `created_on`, `log_type`, `ipaddress`, `full_user_agent_string`, `status`) VALUES
	(11, 1, '2019-01-02 15:04:06', 'login', '::1', 'Mozilla/5.0 (Windows NT 6.1; rv:64.0) Gecko/20100101 Firefox/64.0', 'Y'),
	(12, 1, '2019-01-02 15:04:22', 'login', '::1', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', 'Y'),
	(13, 1, '2019-01-02 15:05:48', 'logout', '::1', 'Mozilla/5.0 (Windows NT 6.1; rv:64.0) Gecko/20100101 Firefox/64.0', 'Y'),
	(14, 1, '2019-01-02 15:06:03', 'logout', '::1', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', 'Y'),
	(15, 1, '2019-01-02 15:29:44', 'login', '::1', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', 'Y'),
	(16, 1, '2019-01-02 15:34:10', 'login', '::1', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', 'Y'),
	(17, 1, '2019-01-02 15:36:21', 'login', '::1', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', 'Y'),
	(18, 1, '2019-01-02 18:32:49', 'login', '::1', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', 'Y'),
	(19, 1, '2019-01-02 18:33:04', 'login', '::1', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', 'Y');
	
/*!40000 ALTER TABLE `user_log` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.user_map_student_details
DROP TABLE IF EXISTS `user_map_student_details`;
CREATE TABLE IF NOT EXISTS `user_map_student_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `parent_unique_id` varchar(100) DEFAULT NULL,
  `parent_name` varchar(100) DEFAULT NULL,
  `mother_name` varchar(100) DEFAULT NULL,
  `occupation` varchar(50) DEFAULT NULL,
  `father_contact` varchar(50) DEFAULT NULL,
  `alternate_contact` varchar(50) DEFAULT NULL,
  `father_email` varchar(50) DEFAULT NULL,
  `father_password` varchar(100) DEFAULT NULL,
  `religion` varchar(50) DEFAULT NULL,
  `nativity` varchar(50) DEFAULT NULL,
  `district` varchar(50) DEFAULT NULL,
  `nationality` varchar(50) DEFAULT NULL,
  `address` text,
  `address2` text,
  `address3` text,
  `address4` text,
  `country_id` int(11) DEFAULT NULL,
  `state_id` int(11) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `zip_code` varchar(50) DEFAULT NULL,
  `parent_image` text,
  `registration` varchar(100) DEFAULT NULL,
  `class_name` varchar(50) DEFAULT NULL,
  `section_id` varchar(50) DEFAULT NULL,
  `roll` varchar(100) DEFAULT NULL,
  `last_school` varchar(255) DEFAULT NULL,
  `last_std` varchar(255) DEFAULT NULL,
  `marks_obtained` varchar(100) DEFAULT NULL,
  `sports_id` varchar(50) DEFAULT NULL,
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `batch_id` varchar(50) DEFAULT NULL,
  `campus_id` int(11) DEFAULT NULL,
  `semester_id` int(11) DEFAULT NULL,
  `degree_id` int(11) DEFAULT NULL,
  `course_type` int(11) DEFAULT NULL COMMENT '1:full_time,2:part_time',
  `blood_group` varchar(50) DEFAULT NULL,
  `mother_tongue` varchar(50) DEFAULT NULL,
  `resident_type` varchar(50) DEFAULT NULL,
  `annual_income` varchar(50) DEFAULT NULL,
  `guardian_name` varchar(255) DEFAULT NULL,
  `address_local` varchar(100) DEFAULT NULL,
  `street_local` varchar(100) DEFAULT NULL,
  `country_id_local` int(5) DEFAULT NULL,
  `state_id_local` int(5) DEFAULT NULL,
  `city_id_local` int(5) DEFAULT NULL,
  `zip_code_local` int(10) DEFAULT NULL,
  `scholarship` varchar(50) DEFAULT NULL,
  `month_passing` varchar(50) DEFAULT NULL,
  `year_passing` int(7) DEFAULT NULL,
  `medium_instr` varchar(50) DEFAULT NULL,
  `mode_of_admission` varchar(50) DEFAULT NULL,
  `reserved` varchar(50) DEFAULT NULL,
  `quota` varchar(50) DEFAULT NULL,
  `student_status` varchar(50) DEFAULT NULL,
  `medical_permission` varchar(50) DEFAULT NULL,
  `doa` date DEFAULT NULL,
  `dop` date DEFAULT NULL,
  `internship_grade` varchar(50) DEFAULT NULL,
  `ward_counsellor` varchar(100) DEFAULT NULL,
  `extra_activites` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `place_of_birth` varchar(255) DEFAULT NULL,
  `differently_abled` enum('Yes','No') DEFAULT 'No',
  `children_of_exserviceman` enum('Yes','No') DEFAULT 'No',
  `children_of_freedom_fighter` enum('Yes','No') DEFAULT 'No',
  `first_graduate` enum('Yes','No') DEFAULT 'No',
  `place_of_residence` varchar(50) DEFAULT 'No',
  `landline_no` varchar(50) DEFAULT 'No',
  `academicvocational` enum('academic','vocational') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=704 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.user_map_student_details: 617 rows
/*!40000 ALTER TABLE `user_map_student_details` DISABLE KEYS */;
INSERT INTO `user_map_student_details` (`id`, `role_id`, `user_id`, `parent_unique_id`, `parent_name`, `mother_name`, `occupation`, `father_contact`, `alternate_contact`, `father_email`, `father_password`, `religion`, `nativity`, `district`, `nationality`, `address`, `address2`, `address3`, `address4`, `country_id`, `state_id`, `city_id`, `zip_code`, `parent_image`, `registration`, `class_name`, `section_id`, `roll`, `last_school`, `last_std`, `marks_obtained`, `sports_id`, `created_on`, `batch_id`, `campus_id`, `semester_id`, `degree_id`, `course_type`, `blood_group`, `mother_tongue`, `resident_type`, `annual_income`, `guardian_name`, `address_local`, `street_local`, `country_id_local`, `state_id_local`, `city_id_local`, `zip_code_local`, `scholarship`, `month_passing`, `year_passing`, `medium_instr`, `mode_of_admission`, `reserved`, `quota`, `student_status`, `medical_permission`, `doa`, `dop`, `internship_grade`, `ward_counsellor`, `extra_activites`, `remark`, `place_of_birth`, `differently_abled`, `children_of_exserviceman`, `children_of_freedom_fighter`, `first_graduate`, `place_of_residence`, `landline_no`, `academicvocational`) VALUES
	(2, 1, 98, 'PAR2', 'Kannan', 'Kavitha', NULL, NULL, NULL, 'PAR98', '123456', '2', NULL, NULL, '1', '10, chennai', NULL, NULL, NULL, 99, 29, NULL, '600015', NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, '2018-08-06 15:08:40', '1', 1, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'No', 'No', 'No', 'No', 'No', 'No', NULL),
	(3, 0, 99, 'PAR3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2', NULL, NULL, '1', NULL, NULL, NULL, NULL, 99, 29, NULL, '600002', NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, '2018-08-06 15:08:40', '1', 1, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'No', 'No', 'No', 'No', 'No', 'No', NULL),
	(4, 0, 100, 'PAR4', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-08-06 15:08:40', '1', 1, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'No', 'No', 'No', 'No', 'No', 'No', NULL),
	(5, 0, 101, 'PAR5', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-08-06 15:08:40', '1', 1, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'No', 'No', 'No', 'No', 'No', 'No', NULL),
	(6, 0, 102, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-08-06 15:08:40', '1', 1, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'No', 'No', 'No', 'No', 'No', 'No', NULL),
	(7, 0, 103, 'PAR7', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-08-06 15:08:40', '1', 1, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'No', 'No', 'No', 'No', 'No', 'No', NULL),
	(8, 0, 104, 'PAR8', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-08-06 15:08:40', '1', 1, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'No', 'No', 'No', 'No', 'No', 'No', NULL),
	(9, 0, 105, 'PAR9', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-08-06 15:08:40', '1', 1, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'No', 'No', 'No', 'No', 'No', 'No', NULL),
	(10, 0, 106, 'PAR10', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-08-06 15:08:40', '1', 1, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'No', 'No', 'No', 'No', 'No', 'No', NULL),
	
/*!40000 ALTER TABLE `user_map_student_details` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.user_map_subadmin_details
DROP TABLE IF EXISTS `user_map_subadmin_details`;
CREATE TABLE IF NOT EXISTS `user_map_subadmin_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `address_line1` text,
  `address_line2` text,
  `address_line3` text,
  `address_line4` text,
  `landline_number` varchar(100) DEFAULT NULL,
  `permission_status` tinyint(4) DEFAULT NULL,
  `subadmin_campus_id` tinyint(4) DEFAULT NULL,
  `upload_type` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.user_map_subadmin_details: 6 rows
/*!40000 ALTER TABLE `user_map_subadmin_details` DISABLE KEYS */;
INSERT INTO `user_map_subadmin_details` (`id`, `user_id`, `address_line1`, `address_line2`, `address_line3`, `address_line4`, `landline_number`, `permission_status`, `subadmin_campus_id`, `upload_type`) VALUES
	(1, 567, 'delhi', 'delhi', 'delhi', 'delhi', NULL, 2, 1, 2),
	(2, 568, 'delhi1', 'delhi1', 'delhi1', 'delhi1', NULL, 0, 6, 2),
	(3, 569, 'delhi ', 'delhi', 'janakpuri', 'india', '7478745787', 0, 6, 2),
	(4, 570, 'delhi', 'delhi', 'delhi', 'delhi', '745478457', 0, 6, 1),
	(5, 574, 'Demo Address1', 'Demo Address1', 'Demo Address1', 'Demo Address1', '7845478478', 0, 1, 2),
	(6, 747, 'delhi', 'delhi', 'delhi', 'delhi', NULL, 2, 1, 2);
/*!40000 ALTER TABLE `user_map_subadmin_details` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.user_map_teacher_details
DROP TABLE IF EXISTS `user_map_teacher_details`;
CREATE TABLE IF NOT EXISTS `user_map_teacher_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `address_line1` varchar(255) DEFAULT NULL,
  `address_line2` varchar(255) DEFAULT NULL,
  `address_line3` varchar(225) DEFAULT NULL,
  `address_line4` varchar(255) DEFAULT NULL,
  `landline_number` varchar(50) DEFAULT NULL,
  `employee_id` varchar(50) DEFAULT NULL,
  `qualification` varchar(100) DEFAULT NULL,
  `date_of_joining` varchar(100) DEFAULT NULL,
  `designation` varchar(100) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `campus` varchar(255) DEFAULT NULL,
  `discipline` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.user_map_teacher_details: 10 rows
/*!40000 ALTER TABLE `user_map_teacher_details` DISABLE KEYS */;
INSERT INTO `user_map_teacher_details` (`id`, `user_id`, `address_line1`, `address_line2`, `address_line3`, `address_line4`, `landline_number`, `employee_id`, `qualification`, `date_of_joining`, `designation`, `department`, `campus`, `discipline`) VALUES
	(2, 25, 'Address Line1', 'Address Line2', 'Address Line3', 'Address Line4', '7878478787', 'SAN001', 'B.Tech', '14-06-2018', '1', 'MCA', '1', '19'),
	(3, 26, 'aa', 'aa', 'aa', 'aa', '7847874747', 'AA001', 'MCA', '14-08-6-2018', '1', 'Department', '1', '12'),
	(4, 27, 'ASsa11', 'saS11', 'sas1111', 'sa11', '32132333', 'sdasd', 'sdas', '14-09-2017', '5', 'sadasd', '3', '10'),
	(5, 32, 'ASsa', 'saS', 'sas', 'sa', '321321', 'sdasd1', 'sdas1', '14-09-2017', '5', 'sadasd', '3', '18'),
	(6, 39, '', '', '', '', '', '123', 'm.Tech', '17-06-2014', '1', 'CSE', '1', '1'),
	(9, 564, 'delhi', 'delhi', 'delhi', 'delhi', '', 'emp001', 'M.Sc', '12-09-2018', '1', 'test', '1', '1'),
	(8, 563, 'delhi,vasant kunj', 'delhi,vasant kunj', 'delhi,vasant kunj', 'delhi,vasant kunj', '', 'TEAC001', 'Msc.In Physics', '25-09-2018', '2', 'Physics', '1', '1'),
	(10, 565, 'delhi1', 'delhi1', 'delhi1', 'delhi1', '', 'testteacher', 'mtech', '09-10-2018', '1', 'dd', '1', '1'),
	(11, 572, 'demo address1', 'demo address2', 'demo address3', 'demo address4', '', '123452', 'PHD', '12-11-2018', '1', 'computer', '1', '1'),
	(12, 575, 'test chennai', 'test chennai', 'test chennai', 'test chennai', '', '45124', 'btech', '19-11-2018', '7', 'btech', '1', '1');
/*!40000 ALTER TABLE `user_map_teacher_details` ENABLE KEYS */;

-- Dumping structure for table tanuvaslivenew.user_map_userdetail_details
DROP TABLE IF EXISTS `user_map_userdetail_details`;
CREATE TABLE IF NOT EXISTS `user_map_userdetail_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `address_line1` varchar(255) NOT NULL,
  `address_line2` varchar(255) NOT NULL,
  `address_line3` varchar(255) NOT NULL,
  `address_line4` varchar(255) NOT NULL,
  `landline_number` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table tanuvaslivenew.user_map_userdetail_details: 2 rows
/*!40000 ALTER TABLE `user_map_userdetail_details` DISABLE KEYS */;
INSERT INTO `user_map_userdetail_details` (`id`, `user_id`, `address_line1`, `address_line2`, `address_line3`, `address_line4`, `landline_number`) VALUES
	(1, 30, '34243', '4324324', '32432', '3421desads', 0),
	(2, 546, 'delhi', 'new delhi', 'vasant vihar', 'vasant bihar', 0);
/*!40000 ALTER TABLE `user_map_userdetail_details` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
