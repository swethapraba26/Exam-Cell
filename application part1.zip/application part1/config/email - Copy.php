<?php

$config['protocol']    = 'smtp';
$config['smtp_host']    = 'mail.parthaedu.com';
$config['smtp_port']    = '587';
$config['smtp_timeout'] = '10';
$config['smtp_user']    = 'admin@parthaedu.com';
$config['smtp_pass']    = 'partha@108';
//$config['charset']    = 'iso-8859-1';
$config['charset']    = 'utf-8';
$config['newline']    = "\r\n";
$config['mailtype'] = 'html'; // or html